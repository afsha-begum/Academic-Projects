import DBlab as db
import csv


class Clinic:
    def __init__(self, row):
        self.clinic_id = row[0]
        self.clinic_name = row[1]
        self.clinic_location = row[2]
        self.timings = row[3]


class ClinicCSV(db.DBbase):
    def __init__(self):
        super().__init__("ClinicManagementDB.sqlite")

    def reset_database(self):

        try:
            sql = """
                DROP TABLE IF EXISTS Clinic;
                
                CREATE TABLE Clinic (
                    clinic_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
                    clinic_name TEXT,
                    clinic_location varchar(100),
                    timings TIME
                    );
            
            """
            super().execute_script(sql)

        except Exception as e:
            print(e)

    def read_clinic_data(self, file_name):
        self.clinic_list = []

        try:
            with open(file_name, "r") as records:
                csv_reader = csv.reader(records)
                next(records)
                for row in csv_reader:
                    clinic = Clinic(row)
                    self.clinic_list.append(clinic)

        except Exception as ex:
            print(ex)

    def load_clinic_data_to_database(self):
        for item in self.clinic_list:
            try:
                super().get_cursor.execute("""INSERT INTO Clinic
                (clinic_id, clinic_name, clinic_location, timings)
                VALUES(?,?,?,?)""", (item.clinic_id, item.clinic_name, item.clinic_location, item.timings))
                super().get_connection.commit()
                print("Saved item", item.clinic_id, item.clinic_name, item.clinic_location, item.timings)

            except Exception as ex:
                print(ex)

    def add_clinic_data(self, clinic_id, clinic_name, clinic_location, timings):
        try:
            super().get_cursor.execute("""INSERT INTO Clinic
                    (clinic_id, clinic_name, clinic_location, timings)
                    VALUES(?,?,?,?)""", (clinic_id, clinic_name, clinic_location, timings))
            super().get_connection.commit()
            print(f"Added {clinic_name} successfully.")
        except Exception as e:
            print("An error has occurred", e)

    def fetch_clinic_data(self, clinic_id=None):
        try:
            if clinic_id is not None:
                retval = super().get_cursor.execute("""SELECT clinic_id, clinic_name, clinic_location, timings
                FROM Clinic 
                WHERE clinic_id = ?;""", (clinic_id,)).fetchone()
                return retval
            else:
                return super().get_cursor.execute("""SELECT clinic_id, clinic_name, clinic_location, timings
                FROM Clinic;""").fetchall()
        except Exception as e:
            print("An error occurred", e)

    def update_clinic_data(self, clinic_id, clinic_name, clinic_location, timings):
        try:
            super().get_cursor.execute(
                "update Clinic set clinic_name= ?, clinic_location= ?, timings= ? where clinic_id = ?;",
                (clinic_name, clinic_location, timings, clinic_id,))
            super().get_connection.commit()
            print(f"Updated record for Doctor ID: {clinic_id} successfully")
        except Exception as e:
            print("An error has occurred", e)

    def delete_clinic_data(self, clinic_id):
        try:
            super().get_cursor.execute("DELETE FROM Clinic where clinic_id = ?;", (clinic_id,))
            super().get_connection.commit()
            print(f"Deleted Doctor ID: {clinic_id} successfully")
            return True
        except Exception as e:
            print("An error has occurred", e)
            return False

class Patient:
    def __init__(self):
        super().__init__("ClinicManagementDB.sqlite")

    def __init__(self, row):
        self.patient_id = row[0]
        self.first_name = row[1]
        self.last_name = row[2]
        self.gender = row[3]
        self.age = row[4]


class PatientCSV(db.DBbase):
    def __init__(self):
        super().__init__("ClinicManagementDB.sqlite")

    def reset_database(self):

        try:
            sql = """
                DROP TABLE IF EXISTS Patient;
                
                CREATE TABLE Patient (
                    patient_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
                    first_name TEXT,
                    last_name TEXT,
                    gender varchar(10),
                    age INTEGER 
            );
            """
            super().execute_script(sql)

        except Exception as e:
            print(e)

    def add_patient_data(self, patient_id, first_name, last_name, gender, age):
        try:
            super().get_cursor.execute("""INSERT INTO Patient
                    (patient_id, first_name, last_name, gender, age)
                    VALUES(?,?,?,?,?)""", (patient_id, first_name, last_name, gender, age))
            super().get_connection.commit()
            print(f"Added patient {first_name} {last_name} successfully.")
        except Exception as e:
            print("An error has occurred", e)

    def read_patient_data(self, file_name):
        self.patient_list = []

        try:
            with open(file_name, "r") as records:
                csv_reader = csv.reader(records)
                next(records)
                for row in csv_reader:
                    patient = Patient(row)
                    self.patient_list.append(patient)

        except Exception as ex:
            print(ex)

    def load_patient_data_to_database(self):
        for item in self.patient_list:
            try:
                super().get_cursor.execute("""INSERT INTO Patient
                    (patient_id, first_name, last_name, gender, age)
                    VALUES(?,?,?,?,?)""",
                                           (
                                               item.patient_id, item.first_name, item.last_name, item.gender,
                                               item.age))
                super().get_connection.commit()
                print("Saved item", item.patient_id, item.first_name, item.last_name, item.gender, item.age)

            except Exception as ex:
                print(ex)

    def fetch_patient_data(self, patient_id=None):
        try:
            if patient_id is not None:
                retval = super().get_cursor.execute("""SELECT patient_id, first_name, last_name, gender, age
                FROM Patient 
                WHERE patient_id = ?;""", (patient_id,)).fetchone()
                return retval
            else:
                return super().get_cursor.execute("""SELECT patient_id, first_name, last_name, gender, age
                FROM Patient;""").fetchall()
        except Exception as e:
            print("An error occurred", e)

    def update_patient_data(self, patient_id, first_name, last_name, gender, age):
        try:
            super().get_cursor.execute(
                "update Patient set first_name= ?, last_name= ?, gender= ?, age= ? where patient_id = ?;",
                (first_name, last_name, gender, age, patient_id))
            super().get_connection.commit()
            print(f"Updated record for patient ID: {patient_id} successfully")
        except Exception as e:
            print("An error has occurred", e)

    def delete_patient_data(self, patient_id):
        try:
            super().get_cursor.execute("DELETE FROM Patient where patient_id = ?;", (patient_id,))
            super().get_connection.commit()
            print(f"Deleted patientID: {patient_id} successfully")
            return True
        except Exception as e:
            print("An error has occurred", e)
            return False


class Doctor:
    def __init__(self, row):
        self.doctor_id = row[0]
        self.first_name = row[1]
        self.last_name = row[2]
        self.gender = row[3]
        self.age = row[4]
        self.speciality = row[5]
        self.date = row[6]
        self.number_of_appointments = row[7]
        self.working_hours = row[8]
        self.clinic_id = row[9]


class DoctorCSV(db.DBbase):
    def __init__(self):
        super().__init__("ClinicManagementDB.sqlite")

    def reset_database(self):

        try:
            sql = """
                DROP TABLE IF EXISTS Doctor;
                
                CREATE TABLE Doctor (
                    doctor_id INTEGER NOT NULL PRIMARY KEY UNIQUE,
                    first_name TEXT,
                    last_name TEXT,
                    gender varchar(10),
                    age INTEGER,
                    speciality varchar(50),
                    date DATE,
                    number_of_appointments INTEGER,
                    working_hours INTEGER,
                    clinic_id INTEGER,
                    FOREIGN KEY (clinic_id) REFERENCES Clinic (clinic_id));
                
            
            """
            super().execute_script(sql)

        except Exception as e:
            print(e)

    def add_doctor_data(self, doctor_id, first_name, last_name, gender, age, speciality, date, number_of_appointments,
                        working_hours, clinic_id):
        try:
            super().get_cursor.execute("""INSERT INTO Doctor
                (doctor_id, first_name, last_name, gender, age, speciality, date, number_of_appointments, working_hours, clinic_id)
                VALUES(?,?,?,?,?,?,?,?,?,?)""", (
            doctor_id, first_name, last_name, gender, age, speciality, date, number_of_appointments, working_hours,
            clinic_id))
            super().get_connection.commit()
            print(f"Added Doctor {first_name} {last_name} successfully.")
        except Exception as e:
            print("An error has occurred", e)

    def read_doctor_data(self, file_name):
        self.doctor_list = []

        try:
            with open(file_name, "r") as records:
                csv_reader = csv.reader(records)
                next(records)
                for row in csv_reader:
                    doctor = Doctor(row)
                    self.doctor_list.append(doctor)

        except Exception as ex:
            print(ex)

    def load_doctor_data_to_database(self):
        for item in self.doctor_list:
            try:
                super().get_cursor.execute("""INSERT INTO Doctor
                (doctor_id, first_name, last_name, gender, age, speciality, date, number_of_appointments, working_hours, clinic_id)
                VALUES(?,?,?,?,?,?,?,?,?,?)""",
                                           (
                                               item.doctor_id, item.first_name, item.last_name, item.gender,
                                               item.age, item.speciality, item.date, item.number_of_appointments,
                                               item.working_hours,
                                               item.clinic_id))
                super().get_connection.commit()
                print("Saved item", item.doctor_id, item.first_name, item.last_name, item.gender,
                      item.age, item.speciality, item.date, item.number_of_appointments, item.working_hours,
                      item.clinic_id)

            except Exception as ex:
                print(ex)

    def fetch_doctor_data(self, doctor_id=None):
        try:
            if doctor_id is not None:
                retval = super().get_cursor.execute("""SELECT doctor_id, first_name, last_name, gender, age, speciality, date, number_of_appointments, working_hours, clinic_id
                FROM Doctor 
                WHERE doctor_id = ?;""", (doctor_id,)).fetchone()
                return retval
            else:
                return super().get_cursor.execute("""SELECT doctor_id, first_name, last_name, gender, age, speciality,date, number_of_appointments, working_hours, clinic_id
                FROM Doctor;""").fetchall()
        except Exception as e:
            print("An error occurred", e)

    def update_doctor_data(self, doctor_id, first_name, last_name, gender, age, speciality, date,
                           number_of_appointments, working_hours, clinic_id):
        try:
            super().get_cursor.execute(
                "update Doctor set first_name= ?, last_name= ?, gender= ?, age= ?, speciality= ?, date= ?, number_of_appointments= ?,working_hours =?, clinic_id= ?  where doctor_id = ?;",
                (first_name, last_name, gender, age, speciality, date, number_of_appointments, working_hours, clinic_id,
                 doctor_id))
            super().get_connection.commit()
            print(f"Updated record for Doctor ID: {doctor_id} successfully")
        except Exception as e:
            print("An error has occurred", e)

    def delete_doctor_data(self, doctor_id):
        try:
            super().get_cursor.execute("DELETE FROM Doctor where doctor_id = ?;", (doctor_id,))
            super().get_connection.commit()
            print(f"Deleted Doctor ID: {doctor_id} successfully")
            return True
        except Exception as e:
            print("An error has occurred", e)
            return False


class Appointment:
    def __init__(self, row):
        self.appointment_id = row[0]
        self.appointment_date = row[1]
        self.reason = row[2]
        self.clinic_id = row[3]
        self.patient_id = row[4]
        self.doctor_id = row[5]


class AppointmentCSV(db.DBbase):
    def __init__(self):
        super().__init__("ClinicManagementDB.sqlite")

    def reset_database(self):

        try:
            sql = """
                DROP TABLE IF EXISTS Appointment;
                
                CREATE TABLE Appointment (
                    appointment_id INTEGER NOT NULL PRIMARY KEY UNIQUE,
                    appointment_date DATE,
                    reason varchar (500),
                    clinic_id INTEGER,
                    patient_id INTEGER,
                    doctor_id INTEGER,
                    FOREIGN KEY (patient_id) REFERENCES Patient (patient_id),
                    FOREIGN KEY (doctor_id) REFERENCES Doctor (doctor_id),
                    FOREIGN KEY (clinic_id) REFERENCES Clinic (clinic_id));
                    
            
            """
            super().execute_script(sql)

        except Exception as e:
            print(e)

    def read_appointment_data(self, file_name):
        self.appointment_list = []

        try:
            with open(file_name, "r") as records:
                csv_reader = csv.reader(records)
                next(records)
                for row in csv_reader:
                    appointment = Appointment(row)
                    self.appointment_list.append(appointment)

        except Exception as ex:
            print(ex)

    def load_appointment_data_to_database(self):
        for item in self.appointment_list:
            try:
                super().get_cursor.execute("""INSERT INTO Appointment
                (appointment_id, appointment_date, reason, clinic_id, patient_id, doctor_id)
                VALUES(?,?,?,?,?,?)""",
                                           (
                                               item.appointment_id, item.appointment_date,
                                               item.reason,
                                               item.clinic_id, item.patient_id, item.doctor_id
                                           ))
                super().get_connection.commit()
                print("Saved item", item.appointment_id, item.appointment_date, item.reason,
                      item.clinic_id, item.patient_id, item.doctor_id)

            except Exception as ex:
                print(ex)

    def add_appointment_data(self, appointment_id, appointment_date, reason, clinic_id, patient_id, doctor_id):
        try:
            appointment_count = super().get_cursor.execute("""SELECT  number_of_appointments
                FROM Doctor 
                WHERE doctor_id = ? and date= ?;""", (doctor_id, appointment_date)).fetchone()
            if appointment_count < (16,):
                super().get_cursor.execute("""INSERT INTO Appointment
                    (appointment_id, appointment_date, reason, clinic_id, patient_id, doctor_id)
                    VALUES(?,?,?,?,?,?)""",
                                           (appointment_id, appointment_date, reason, clinic_id, patient_id, doctor_id))
                super().get_connection.commit()
                print(f"Added Appointment {appointment_id} successfully.")
            else:
                print("Cannot Schedule Appointment as the appointment limit is 16")
        except Exception as e:
            print("An error has occurred", e)

    def fetch_appointment_data(self, appointment_id=None):
        try:
            if appointment_id is not None:
                retval = super().get_cursor.execute("""SELECT appointment_id, appointment_date, reason, clinic_id, patient_id, doctor_id
                FROM Appointment 
                WHERE appointment_id = ?;""", (appointment_id,)).fetchone()
                return retval
            else:
                return super().get_cursor.execute("""SELECT appointment_id, appointment_date, reason, clinic_id, patient_id, doctor_id
                FROM Appointment;""").fetchall()
        except Exception as e:
            print("An error occurred", e)

    def update_appointment_data(self, appointment_id, appointment_date, reason, clinic_id, patient_id, doctor_id):
        try:
            super().get_cursor.execute(
                "update Appointment set appointment_date= ?, reason= ?, clinic_id= ?, patient_id= ?, doctor_id= ? where appointment_id = ?;",
                (appointment_date, reason, clinic_id, patient_id, doctor_id, appointment_id))
            super().get_connection.commit()
            print(f"Updated record for Appointment ID: {appointment_id} successfully")
        except Exception as e:
            print("An error has occurred", e)

    def delete_appointment_data(self, appointment_id):
        try:
            super().get_cursor.execute("DELETE FROM Appointment where appointment_id = ?;", (appointment_id,))
            super().get_connection.commit()
            print(f"Deleted Appointment ID: {appointment_id} successfully")
            return True
        except Exception as e:
            print("An error has occurred", e)
            return False


class Project:
    def run(self):
        options = {"1": "Add a Patient",
                   "2": "Get all Patient Details",
                   "3": "Get Patient Details by ID",
                   "4": "Update Patient Details",
                   "5": "Delete Patient Details",
                   "6": "Add Clinic Details",
                   "7": "Get all Clinic Details",
                   "8": "Get Clinic Details by ID",
                   "9": "Update Clinic Details",
                   "10": "Delete Clinic Details",
                   "11": "Add Doctor Details",
                   "12": "Get Doctor Details",
                   "13": "Get Doctor Details by ID",
                   "14": "Update Doctor Details",
                   "15": "Delete Doctor Details",
                   "16": "Schedule Appointment",
                   "17": "Get Appointment Details",
                   "18": "Get Appointment Details by ID",
                   "19": "Update Appointment Details",
                   "20": "Delete Appointment Details",
                   "exit": "Exit"

                   }

        print("Welcome to Doctor/ Patient Appointment Scheduler program, please choose a selection")
        clinic = ClinicCSV()
        doctor = DoctorCSV()
        patient = PatientCSV()
        appointment = AppointmentCSV()
        user_selection = ""
        try:
            while user_selection != "exit":
                print("*** Option List ***")
                for option in options.items():
                    print(option)
                user_selection = input("Select an option: ").lower()
                if user_selection == "1":
                    patient = PatientCSV()
                    patient_id = input("Enter patient ID: ")
                    first_name = input("Enter first name: ")
                    last_name = input("Enter last name: ")
                    gender = input("Enter gender: ")
                    age = input("Enter age: ")
                    patient.add_patient_data(patient_id,first_name, last_name, gender, age)
                    print("Done\n")
                    input("Press return to continue")
                elif user_selection == "2":
                    results = patient.fetch_patient_data()
                    for item in results:
                        print(item)
                    input("Press return to continue")
                elif user_selection == "3":
                    patient_id = input("Enter Patient Id: ")
                    results = patient.fetch_patient_data(patient_id)
                    print(results)
                    input("Press return to continue")
                elif user_selection == "4":
                    patient_id = input("Enter Patient id: ")
                    first_name = input("Enter first name: ")
                    last_name = input("Enter last name: ")
                    gender = input("Enter gender: ")
                    age = input("Enter age: ")
                    patient.update_patient_data(patient_id, first_name, last_name, gender, age)
                    print(patient.fetch_patient_data(patient_id))
                    input("press return to continue")
                elif user_selection == "5":
                    patient_id = input("Enter patient id: ")
                    patient.delete_patient_data(patient_id)
                    print("Done\n")
                    input("Press return to continue")

                elif user_selection == "6":
                    clinic_id = input("Enter Clinic id: ")
                    clinic_name = input("Enter clinic name: ")
                    clinic_location = input("Enter location: ")
                    timings = input("Enter timings: ")
                    clinic.add_clinic_data(clinic_id, clinic_name, clinic_location, timings)
                    print("Done\n")
                    input("Press return to continue")
                elif user_selection == "7":
                    results = clinic.fetch_clinic_data()
                    for item in results:
                        print(item)
                    input("Press return to continue")
                elif user_selection == "8":
                    clinic_id = input("Enter Clinic Id: ")
                    results = clinic.fetch_clinic_data(clinic_id)
                    print(results)
                    input("Press return to continue")
                elif user_selection == "9":
                    clinic_id = input("Enter Clinic id: ")
                    clinic_name = input("Enter clinic name: ")
                    location = input("Enter location: ")
                    timings = input("Enter timings: ")
                    clinic.update_clinic_data(clinic_id, clinic_name, location, timings)
                    print(clinic.fetch_clinic_data(clinic_id))
                    input("press return to continue")
                elif user_selection == "10":
                    clinic_id = input("Enter clinic id: ")
                    clinic.delete_clinic_data(clinic_id)
                    print("Done\n")
                    input("Press return to continue")
                elif user_selection == "11":
                    doctor_id = input("Enter doctor id: ")
                    first_name = input("Enter first name: ")
                    last_name = input("Enter last name: ")
                    gender = input("Enter gender: ")
                    age = input("Enter age: ")
                    speciality = input("Enter Speciality: ")
                    date = input("Enter date: ")
                    number_of_appointments = input("Enter number_of_appointments: ")
                    working_hours = input("Enter working_hours: ")
                    doctor.add_doctor_data(doctor_id, first_name, last_name, gender, age, speciality, date,
                                           number_of_appointments, working_hours)
                    print("Done\n")
                    input("Press return to continue")
                elif user_selection == "12":
                    results = doctor.fetch_doctor_data()
                    for item in results:
                        print(item)
                    input("Press return to continue")
                elif user_selection == "13":
                    doctor_id = input("Enter Doctor Id: ")
                    results = doctor.fetch_doctor_data(doctor_id)
                    print(results)
                    input("Press return to continue")
                elif user_selection == "14":
                    doctor_id = input("Enter Doctor Id: ")
                    first_name = input("Enter first name: ")
                    last_name = input("Enter last name: ")
                    gender = input("Enter gender: ")
                    age = input("Enter age: ")
                    speciality = input("Enter Speciality: ")
                    date = input("Enter date: ")
                    number_of_appointments = input("Enter number of appointments: ")
                    working_hours = input("Enter working hours: ")
                    doctor.update_doctor_data(doctor_id, first_name, last_name, gender, age, speciality, date,
                                              number_of_appointments, working_hours)
                    print(doctor.fetch_doctor_data(doctor_id))
                    input("press return to continue")
                elif user_selection == "15":
                    doctor_id = input("Enter doctor id: ")
                    doctor.delete_doctor_data(doctor_id)
                    print("Done\n")
                    input("Press return to continue")

                elif user_selection == "11":
                    doctor_id = input("Enter doctor id: ")
                    first_name = input("Enter first name: ")
                    last_name = input("Enter last name: ")
                    gender = input("Enter gender: ")
                    age = input("Enter age: ")
                    speciality = input("Enter Speciality: ")
                    date = input("Enter date: ")
                    number_of_appointments = input("Enter number_of_appointments: ")
                    working_hours = input("Enter working_hours: ")
                    doctor.add_doctor_data(doctor_id, first_name, last_name, gender, age, speciality, date,
                                           number_of_appointments, working_hours)
                    print("Done\n")
                    input("Press return to continue")
                elif user_selection == "12":
                    results = doctor.fetch_doctor_data()
                    for item in results:
                        print(item)
                    input("Press return to continue")
                elif user_selection == "13":
                    doctor_id = input("Enter Doctor Id: ")
                    results = doctor.fetch_doctor_data(doctor_id)
                    print(results)
                    input("Press return to continue")
                elif user_selection == "14":
                    doctor_id = input("Enter Doctor Id: ")
                    first_name = input("Enter first name: ")
                    last_name = input("Enter last name: ")
                    gender = input("Enter gender: ")
                    age = input("Enter age: ")
                    speciality = input("Enter Speciality: ")
                    date = input("Enter date: ")
                    number_of_appointments = input("Enter number of appointments: ")
                    working_hours = input("Enter working hours: ")
                    doctor.update_doctor_data(doctor_id, first_name, last_name, gender, age, speciality, date,
                                              number_of_appointments, working_hours)
                    print(doctor.fetch_doctor_data(doctor_id))
                    input("press return to continue")
                elif user_selection == "15":
                    doctor_id = input("Enter doctor id: ")
                    doctor.delete_doctor_data(doctor_id)
                    print("Done\n")
                    input("Press return to continue")

                elif user_selection == "16":
                    appointment_id = input("Enter appointment id: ")
                    appointment_date = input("Enter appointment date: ")
                    reason = input("Enter reason: ")
                    clinic_id = input("Enter clinic Id: ")
                    patient_id = input("Enter patient Id: ")
                    doctor_id = input("Enter doctor Id: ")
                    appointment.add_appointment_data(appointment_id, appointment_date, reason,clinic_id, patient_id, doctor_id)
                    print("Done\n")
                    input("Press return to continue")
                elif user_selection == "17":
                    results = appointment.fetch_appointment_data()
                    for item in results:
                        print(item)
                    input("Press return to continue")
                elif user_selection == "18":
                    appointment_id = input("Enter Appointment Id: ")
                    results = appointment.fetch_appointment_data(appointment_id)
                    print(results)
                    input("Press return to continue")
                elif user_selection == "19":
                    appointment_id = input("Enter appointment id: ")
                    appointment_date = input("Enter appointment date: ")
                    reason = input("Enter reason: ")
                    clinic_id = input("Enter clinic Id: ")
                    patient_id = input("Enter patient Id: ")
                    doctor_id = input("Enter doctor Id: ")
                    appointment.update_appointment_data(appointment_id, appointment_date, reason,clinic_id, patient_id, doctor_id)
                    print(appointment.fetch_appointment_data(appointment_id))
                    input("press return to continue")
                elif user_selection == "20":
                    appointment_id = input("Enter appointment id: ")
                    appointment.delete_appointment_data(appointment_id)
                    print("Done\n")
                    input("Press return to continue")
        except Exception as e:
            print(e)



project = Project()
project.run()

