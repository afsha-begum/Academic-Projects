
import pandas as pd
import os
import json
import numpy as np
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
import glob

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 4, 13, 0, 0),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=2),
    'catchup': False,
}

dag = DAG(
    'transform_and_combine',
    default_args=default_args,
    description='A DAG to transform and merge weather and aq data',
    schedule_interval=None,
)


def combine_json_files(**kwargs): # combine weather data files into dataframe
  # Directory containing JSON files
  json_folder_path = '/home/airflow/gcs/weather_data' #change to actual bucket path

  # List all JSON files in the directory
  json_files = glob.glob(os.path.join(json_folder_path, '*.json'))

  # Initialize an empty DataFrame to store all JSON data
  combined_json_data = pd.DataFrame()

  # Loop through the JSON files and concatenate them into the DataFrame
  for file in json_files:
      with open(file, 'r') as f:
          data = json.load(f)
          # Assuming 'current' is a common key in all your JSON files:
          if 'current' in data:
              df = pd.json_normalize(data['current'])  # Normalize the 'current' dictionary
              # Extract county name from the file name
              county_name = os.path.basename(file).split('_')[0]  # Splits by underscore and takes the first part
              # Add the county name as a new column
              df['County'] = county_name
              # Add data from this file to combined file
              combined_json_data = pd.concat([combined_json_data, df], ignore_index=True)

  # Rename 'dt' to 'dtstamp' in the combined JSON data
  combined_json_data.rename(columns={'dt': 'dtstamp'}, inplace=True)

  # Remove duplicates from the JSON DataFrame based on the raw datetime 'dt' field
  combined_json_data.drop_duplicates(subset=['dtstamp','County'], inplace=True)

  # Convert 'dt' to datetime and adjust to keep date and hour
  combined_json_data['dtstamp'] = pd.to_datetime(combined_json_data['dtstamp'], unit='s').dtstamp.floor('H')
  # Convert datetime from UTC to MDT (-7:00)
  combined_json_data['dtstamp'] = combined_json_data['dtstamp'] - pd.Timedelta(hours=7)


  return combined_json_data

def clean_and_transform_csv(**kwargs): # clean and transform air quality files into dataframe
  # Directory containing CSV files
  csv_file_path = '/home/airflow/gcs/air_quality_data'  #change to actual bucket path

  # List all CSV files in the directory
  csv_files = glob.glob(os.path.join(csv_file_path, '*.csv'))

  # Initialize an empty DataFrame to store all CSV data
  csv_data = pd.DataFrame()

  # Loop through the CSV files and concatenate them into the DataFrame
  for file in csv_files:
      with open(file, 'r') as f:
          # load csv into a df
          data = pd.read_csv(file) # load csv into a df

      # Remove duplicates from the CSV DataFrame based on the raw 'dtstamp' field
      data.drop_duplicates(subset='dtstamp', inplace=True)

      # Convert 'dtstamp' to datetime and adjust to keep date and hour
      data['dtstamp'] = pd.to_datetime(data['dtstamp']).dt.floor('H')

      # Extract county name from the file name
      county_name = os.path.basename(file).split('_')[0]  # Splits by underscore and takes the first part
      # Add the county name as a new column
      data['County'] = county_name

      # Add the county data to final dataframe
      csv_data = pd.concat([csv_data, data], ignore_index=True)

  return csv_data

# STEP 3: MERGE DATAFRAMES AND SAVE TO CSV FILE
def join_dataframes(**kwargs):
  # get data from previous tasks
  combined_json_data = kwargs['ti'].xcom_pull(task_ids='combine_json_files')
  csv_data = kwargs['ti'].xcom_pull(task_ids='clean_and_transform_csv')

  # Merge DataFrames on 'dtstamp'
  merged_data = pd.merge(csv_data, combined_json_data, on=['dtstamp', 'County'], how='inner')

  # Replace -9999 with NaN across the entire DataFrame
  merged_data.replace(-9999, 'NaN', inplace=True)

  # Save the merged data to a CSV file
  output_file_path = '/home/airflow/gcs/data/merged_data.csv' # replace with bucket path
  merged_data.to_csv(output_file_path, index=False)

  print("Merged data saved to:", output_file_path)

combine_json = PythonOperator(
  task_id='combine_json_files',
  python_callable=combine_json_files,
  provide_context=True,
  dag=dag,
)

combine_csv = PythonOperator(
  task_id='clean_and_transform_csv',
  python_callable=clean_and_transform_csv,
  provide_context=True,
  dag=dag,
)

join_data = PythonOperator(
  task_id='join_dataframes',
  python_callable=join_dataframes,
  provide_context=True,
  dag=dag,
)

[combine_json, combine_csv] >> join_data
