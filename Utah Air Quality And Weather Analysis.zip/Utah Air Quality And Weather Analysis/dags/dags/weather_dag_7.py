
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
import pandas as pd
import requests
import json

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 4, 1, 17, 0),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'catchup': False,
}

dag = DAG(
    'weather_data_collection',
    default_args=default_args,
    description='A simple DAG to fetch weather data',
    schedule_interval=timedelta(hours=1),
)

def fetch_and_save_weather_data(**kwargs):
    locations = kwargs['ti'].xcom_pull(task_ids='read_csv_to_dict')
    API_KEY = "01f1de7fed99d854e6a9c72bc29596ce"
    API_ENDPOINT = "https://api.openweathermap.org/data/3.0/onecall"

    for location in locations:
        params = {
            "lat": location['lat'],
            "lon": location['lon'],
            "exclude": "minutely,daily,hourly,alerts",
            "appid": API_KEY,
            "units": "metric"
        }
        response = requests.get(API_ENDPOINT, params=params)
        if response.status_code == 200:
            data = response.json()
            directory_path = '/home/airflow/gcs/data'
            filename = f"{directory_path}/{location['name']}_{datetime.now().strftime('%Y%m%d%H%M%S')}.json"
            with open(filename, 'w') as f:
                json.dump(data, f)
            print(f"Data for {location['name']} saved.")
        else:
            print(f"Failed to fetch data for {location['name']}.")

def read_csv_to_dict(**kwargs):
    df = pd.read_csv('/home/airflow/gcs/dags/Locations.csv')
    locations = df.to_dict('records')
    return locations

read_csv = PythonOperator(
    task_id='read_csv_to_dict',
    python_callable=read_csv_to_dict,
    provide_context=True,
    dag=dag,
)

fetch_save_weather = PythonOperator(
    task_id='fetch_and_save_weather_data',
    python_callable=fetch_and_save_weather_data,
    provide_context=True,
    dag=dag,
)

read_csv >> fetch_save_weather
