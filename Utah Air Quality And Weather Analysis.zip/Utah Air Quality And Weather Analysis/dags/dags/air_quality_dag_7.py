
# import packages
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
import pandas as pd
import requests
import csv

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 4, 13, 0, 0),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'catchup': False,
}

dag = DAG(
    'air_data_collection',
    default_args=default_args,
    description='A simple DAG to fetch air quality data',
    schedule_interval=None,
)

# read location csv
def read_csv_to_dict(**kwargs):
    df = pd.read_csv('/home/airflow/gcs/dags/Locations_AQ.csv')
    locations = df.to_dict('records')
    return locations

# function to loop through locations and pull csv data
def fetch_and_save_aq_data(**kwargs):
    # get locations
    locations = kwargs['ti'].xcom_pull(task_ids='read_csv_to_dict')

    for location in locations:
      # define variables
      directory_path = '/home/airflow/gcs/data'
      filename = f"{directory_path}/{location['name']}_{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"

      # get csv data and save to object storage
      try:
        df = pd.read_csv(location['url'], sep = '\t')
        df.to_csv(filename, index=False)
        print(f"CSV file saved as '{filename}'")
      except Exception as e:
        print(f"Error downloading or saving CSV: {e}")

read_csv = PythonOperator(
    task_id='read_csv_to_dict',
    python_callable=read_csv_to_dict,
    provide_context=True,
    dag=dag,
)

fetch_save_aq = PythonOperator(
    task_id='fetch_and_save_aq_data',
    python_callable=fetch_and_save_aq_data,
    provide_context=True,
    dag=dag,
)

read_csv >> fetch_save_aq
