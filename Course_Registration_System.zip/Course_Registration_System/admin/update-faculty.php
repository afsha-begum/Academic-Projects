<?php
	$page_roles = array('admin');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die($conn->connect_error);
	
	if (isset($_GET['faculty_id'])) {
		$faculty_id = $conn->real_escape_string($_GET['faculty_id']);
		$query = "SELECT * FROM faculty WHERE faculty_id='$faculty_id'";
		$result = $conn->query($query);
		
		if (!$result) die($conn->error);
		$row = $result->fetch_array(MYSQLI_ASSOC);
		} elseif (isset($_POST['update'])) {
		$faculty_id = $conn->real_escape_string($_POST['faculty_id']);
		$first_name = $conn->real_escape_string($_POST['first_name']);
		$last_name = $conn->real_escape_string($_POST['last_name']);
		$department = $conn->real_escape_string($_POST['department']);
		$course_id = $conn->real_escape_string($_POST['course_id']);
		$is_active = $conn->real_escape_string($_POST['is_active']);
		
		$query = "UPDATE faculty SET first_name='$first_name', last_name='$last_name', department='$department', course_id='$course_id', is_active='$is_active' WHERE faculty_id='$faculty_id'";
		
		$result = $conn->query($query);
		if (!$result) die($conn->error);
		
		header("Location: faculty-list.php");
		exit;
	}
	
	$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Update Faculty</title>
		<style>
			body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
			}
			.container {
            background-color: #ffffff;
            padding: 20px;
            max-width: 400px;
            margin: 20px auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
			}
			h2 {
            text-align: center;
            color: #333;
			}
			form {
            display: flex;
            flex-direction: column;
			}
			label {
            margin-top: 10px;
			}
			input[type="text"],
			input[type="email"],
			input[type="number"],
			button {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
			}
			button {
            background-color: #0078d4;
            color: white;
            cursor: pointer;
            border: none;
            margin-top: 20px;
			}
			button:hover {
			background-color: #0056b3;
			}
			.header {
			width: 100%;
			padding: 10px;
			text-align: right;
			background-color: #f2f2f2;
			}
		</style>
	</head>
	<body>
		<div class="header">
			<a href="logout.php" class="logout-link">Logout</a> 
		</div>
		<?php if (isset($row)): ?>
		<div class="container">
			<h2>Update Faculty</h2>
			<form method="post" action="update-faculty.php">
				<input type="hidden" name="faculty_id" value="<?php echo htmlspecialchars($row['faculty_id']); ?>">
				
				
				<label for="first_name">First Name</label>
				<input type="text" id="first_name" name="first_name" required value="<?php echo htmlspecialchars($row['first_name']); ?>">
				
				
				<label for="last_name">Last Name</label>
				<input type="text" id="last_name" name="last_name" required value="<?php echo htmlspecialchars($row['last_name']); ?>">
				
				
				<label for="department">Department</label>
				<input type="text" id="department" name="department" required value="<?php echo htmlspecialchars($row['department']); ?>">
				
				<label for="course_id">Course_ID</label>
				<input type="number" id="course_id" name="course_id" required value="<?php echo htmlspecialchars($row['course_id']); ?>">
				
				<label for="is_active">Active</label>
				<input type="number" id="is_active" name="is_active" required value="<?php echo htmlspecialchars($row['is_active']); ?>">
				
				<button type="submit" name="update">Update</button>
			</form>
		</div>
		<?php else: ?>
		<p>Faculty data not found.</p>
		<?php endif; ?>
		
	</body>
</html>
