<?php
	
$hn = 'localhost:3306';
$db = 'registration';
$un = 'root';
$pw = '';








?>