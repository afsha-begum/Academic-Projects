<?php
	
	$page_roles = array('admin');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
	
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		
		$course_name = $conn->real_escape_string($_POST['course_name']);
		$course_description = $conn->real_escape_string($_POST['course_description']);
		$credit_hours = $conn->real_escape_string($_POST['credit_hours']);
		$department = $conn->real_escape_string($_POST['department']);
		$semester_id = $conn->real_escape_string($_POST['semester_id']);
		$faculty_id = $conn->real_escape_string($_POST['faculty_id']);
		$course_start_date = $conn->real_escape_string($_POST['course_start_date']);
		$course_end_date = $conn->real_escape_string($_POST['course_end_date']);
		$course_schedule = $conn->real_escape_string($_POST['course_schedule']);
		$is_active = $conn->real_escape_string($_POST['is_active']);
		
		
		$query = "INSERT INTO course (course_name, course_description, credit_hours, department, semester_id, faculty_id, course_start_date, course_end_date, course_schedule, is_active) 
		VALUES ('$course_name', '$course_description', '$credit_hours', '$department', '$semester_id', '$faculty_id', '$course_start_date', '$course_end_date', '$course_schedule', '$is_active')";
		
		$result = $conn->query($query);
		if (!$result) die("Database access failed: " . $conn->error);
		
		
		header("Location: course-list.php");
		exit;
	}
	
	$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Add Course</title>
		<style>
			body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
			}
			.container {
            background-color: #ffffff;
            padding: 20px;
            max-width: 400px;
            margin: 20px auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
			}
			h2 {
            text-align: center;
            color: #333;
			}
			form {
            display: flex;
            flex-direction: column;
			}
			label {
            margin-top: 10px;
			}
			input[type="text"],
			input[type="email"],
			input[type="number"],
			button {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 90%;
			}
			button {
			background-color: #0078d4;
            
            color: white;
            cursor: pointer;
            border: none;
            margin-top: 20px;
			}
			button:hover {
            background-color: #0056b3;
			}
			.header {
			width: 100%;
			padding: 10px;
			text-align: right;
			background-color: #f2f2f2;
			}
		</style>
	</head>
	<body>
		<div class="header">
			<a href="logout.php" class="logout-link">Logout</a> 
		</div>
		<div class="container">
			<h2>Add Course</h2>
			<form method="post" action="add-course.php">
				
				<label for="course_name">Course Name</label>
				<input type="text" id="course_name" name="course_name" required>
				
				<label for="course_description">Course Description</label>
				<input type="text" id="course_description" name="course_description" required>
				
				<label for="credit_hours">Credit Hours</label>
				<input type="number" id="credit_hours" name="credit_hours" required>
				
				
				<label for="department">Department</label>
				<input type="text" id="department" name="department" required>
				
				<label for="semester_id">Semester ID</label>
				<input type="number" id="semester_id" name="semester_id" required>
				
				
				<label for="faculty_id">Faculty ID</label>
				<input type="number" id="faculty_id" name="faculty_id" required>
				
				<label for="course_start_date">Course Start Date</label>
				<input type="date" id="course_start_date" name="course_start_date" required>
				
				<label for="course_end_date">Course End Date</label>
				<input type="date" id="course_end_date" name="course_end_date" required>
				
				<label for="course_schedule">Course Schedule</label>
				<input type="text" id="course_schedule" name="course_schedule" required>
				
				
				<label for="is_active">Active</label>
				<input type="number" id="is_active" name="is_active" required>
				
				<button type="submit">Add</button>
			</form>
		</div>
		
	</body>
</html>
