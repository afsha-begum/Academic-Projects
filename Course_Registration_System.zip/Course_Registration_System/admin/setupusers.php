<?php

require_once 'login.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

// Add the DROP TABLE IF EXISTS query
$query = "DROP TABLE IF EXISTS users";
$result = $conn->query($query);
if(!$result) die($conn->error);

// Code for create user table here
$query = "CREATE TABLE users(
    forename VARCHAR(128) NOT NULL,
    surname VARCHAR(128) NOT NULL,
    username VARCHAR(128) NOT NULL UNIQUE,
    password VARCHAR(128) NOT NULL
)";
$result = $conn->query($query);
if(!$result) die($conn->error);

// Bill Smith - Admin
$forename = 'Bill';
$surname = 'Smith';
$username = 'bsmith';
$password = 'mysecret';
$token = password_hash($password, PASSWORD_DEFAULT);
add_user($conn, $forename, $surname, $username, $token);

// Pauline Jones - Advisor
$forename = 'Pauline';
$surname = 'Jones';
$username = 'pjones';
$password = 'acrobat';
$token = password_hash($password, PASSWORD_DEFAULT);
add_user($conn, $forename, $surname, $username, $token);

// John Doe - Student
$forename = 'John';
$surname = 'Doe';
$username = 'jdoe';
$password = 'science';
$token = password_hash($password, PASSWORD_DEFAULT);
add_user($conn, $forename, $surname, $username, $token);


function add_user($conn, $forename, $surname, $username, $token){
    // Code to add user here
    $query = "INSERT INTO users(forename, surname, username, password) VALUES ('$forename', '$surname', '$username', '$token')";
    $result = $conn->query($query);
    if(!$result) die($conn->error);
}

?>