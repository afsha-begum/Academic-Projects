<?php
	
	$page_roles = array('admin');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
	
	
	if (isset($_POST['inactivate'])) {
		$faculty_id = $_POST['faculty_id'];
		
		
		if (!filter_var($faculty_id, FILTER_VALIDATE_INT)) {
			die("Invalid faculty ID");
		}
		
		
		$stmt = $conn->prepare("UPDATE faculty SET is_active = 0 WHERE faculty_id = ?");
		if (!$stmt) die("Prepare statement failed: " . $conn->error);
		
		
		$stmt->bind_param("i", $faculty_id);
		if (!$stmt->execute()) die("Execute failed: " . $stmt->error);
		
		
		if ($stmt->affected_rows > 0) {
			
			header("Location: faculty-list.php");
			exit;
			} else {
			echo "No faculty was inactivated (perhaps the faculty was already inactive or doesn't exist).";
		}
		
		
		$stmt->close();
	}
	
	
	$conn->close();
?>
