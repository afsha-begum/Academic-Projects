<?php
	
	$page_roles = array('admin');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
	
	
	if (isset($_POST['inactivate'])) {
		$advisor_id = $_POST['advisor_id'];
		
		
		if (!filter_var($advisor_id, FILTER_VALIDATE_INT)) {
			die("Invalid advisor ID");
		}
		
		// UPDATE query to set 'is_active' to 0 (false)
		$stmt = $conn->prepare("UPDATE advisor SET is_active = 0 WHERE advisor_id = ?");
		if (!$stmt) die("Prepare statement failed: " . $conn->error);
		
		
		$stmt->bind_param("i", $advisor_id);
		if (!$stmt->execute()) die("Execute failed: " . $stmt->error);
		
		
		if ($stmt->affected_rows > 0) {
			
			header("Location: advisor-list.php");
			exit;
			} else {
			echo "No advisor was inactivated (perhaps the advisor was already inactive or doesn't exist).";
		}
		
		
		$stmt->close();
	}
	
	
	$conn->close();
?>
