<?php
	$page_roles = array('admin', 'advisor');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Fetch Student Details</title>
		<style>
			body {
			font-family: Arial, sans-serif;
			background-color: #f2f2f2;
			margin: 0;
			padding: 20px;
			display: flex;
			flex-direction: column;
			align-items: center;
			}
			.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 10px 20px;
			background-color: #fff;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
			width: 100%;
			}
			.footer {
			text-align: center;
			padding: 20px;
			background-color: #fff;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
			position: fixed;
			bottom: 0;
			width: 100%;
			}
			form {
			background-color: #fff;
			padding: 20px;
			margin-top: 20px;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
			border-radius: 8px;
			}
			label, input {
			display: block;
			width: 100%;
			margin-bottom: 15px;
			}
			input[type="submit"] {
			background-color: #007bff;
			color: white;
			padding: 10px;
			border: none;
			border-radius: 4px;
			cursor: pointer;
			}
			input[type="submit"]:hover {
			background-color: #0056b3;
			}
		</style>
	</head>
	<body>
		
		<div class="header">
			<img src="logo.jpg" alt="INTI logo" height="50" width="50" class="logo">
			<div class="admin-portal">Admin Portal</div>
			<a href="logout.php">Logout</a>
		</div>
		
		<h2>Fetch Student Details</h2>
		
		<form action="generate-student-list.php" method="post">
			<label for="gpa">Filter by GPA:</label>
			<input type="text" name="gpa" id="gpa" placeholder="Enter GPA" required>
			
			<label for="course_name">Filter by Course Name:</label>
			<input type="text" name="course_name" id="course_name" placeholder="Enter Course Name" required>
			
			<input type="submit" value="Fetch Student Details">
		</form>
		
		<div class="footer">
			<p>&copy; 2023 Your College. All rights reserved.</p>
		</div>
		
	</body>
</html>

