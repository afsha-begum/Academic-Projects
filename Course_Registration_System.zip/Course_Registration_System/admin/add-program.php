<?php
	
	$page_roles = array('admin', 'advisor');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
	
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		
		$name = $conn->real_escape_string($_POST['name']);
		$type = $conn->real_escape_string($_POST['type']);
		$department = $conn->real_escape_string($_POST['department']);
		$advisor_id = $conn->real_escape_string($_POST['advisor_id']);
		
		
		
		$query = "INSERT INTO program (name, type, department, advisor_id) VALUES ('$name', '$type', '$department', '$advisor_id')";
		
		$result = $conn->query($query);
		if (!$result) die("Database access failed: " . $conn->error);
		
		
		header("Location: program-list.php");
		exit;
	}
	
	$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Add Program</title>
		<style>
			body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
			}
			.container {
            background-color: #ffffff;
            padding: 20px;
            max-width: 400px;
            margin: 20px auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
			}
			h2 {
            text-align: center;
            color: #333;
			}
			form {
            display: flex;
            flex-direction: column;
			}
			label {
            margin-top: 10px;
			}
			input[type="text"],
			input[type="email"],
			input[type="number"],
			button {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 90%;
			}
			button {
            background-color: #0078d4;
            
            color: white;
            cursor: pointer;
            border: none;
            margin-top: 20px;
			}
			button:hover {
            background-color: #0056b3;
			}
			.header {
			width: 100%;
			padding: 10px;
			text-align: right;
			background-color: #f2f2f2;
			}
		</style>
	</head>
	<body>
		
		<div class="header">
			<a href="logout.php" class="logout-link">Logout</a> 
		</div>
		
		<div class="container">
			<h2>Add Program</h2>
			<form method="post" action="add-program.php">
				
				
				<label for="name">Name</label>
				<input type="text" id="name" name="name" required>
				
				<label for="type">Type</label>
				<input type="text" id="type" name="type" required>
				
				<label for="department">Department</label>
				<input type="text" id="department" name="department" required>
				
				<label for="advisor_id">Advisor ID</label>
				<input type="number" id="advisor_id" name="advisor_id" required>
				
				<button type="submit">Add</button>
			</form>
		</div>
		
	</body>
</html>