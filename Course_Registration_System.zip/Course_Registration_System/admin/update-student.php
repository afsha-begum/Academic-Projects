<?php
	$page_roles = array('admin');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die($conn->connect_error);
	
	if (isset($_GET['student_id'])) {
		$student_id = $conn->real_escape_string($_GET['student_id']);
		$query = "SELECT * FROM student WHERE student_id='$student_id'";
		$result = $conn->query($query);
		
		if (!$result) die($conn->error);
		$row = $result->fetch_array(MYSQLI_ASSOC);
		} elseif (isset($_POST['update'])) {
		$student_id = $conn->real_escape_string($_POST['student_id']);
		$first_name = $conn->real_escape_string($_POST['first_name']);
		$last_name = $conn->real_escape_string($_POST['last_name']);
		$phone_number = $conn->real_escape_string($_POST['phone_number']);
		$address = $conn->real_escape_string($_POST['address']);
		$email = $conn->real_escape_string($_POST['email']);
		$gpa = $conn->real_escape_string($_POST['gpa']);
		$major = $conn->real_escape_string($_POST['major']);
		$year = $conn->real_escape_string($_POST['year']);
		$enrollment_id = $conn->real_escape_string($_POST['enrollment_id']);
		$advisor_id = $conn->real_escape_string($_POST['advisor_id']);
		$program_id = $conn->real_escape_string($_POST['program_id']);
		$is_active = $conn->real_escape_string($_POST['is_active']);
		
		$query = "UPDATE student SET first_name='$first_name', last_name='$last_name', phone_number='$phone_number', 
        address='$address', email='$email', gpa='$gpa', major='$major', year='$year',
        enrollment_id='$enrollment_id', advisor_id='$advisor_id', program_id='$program_id', is_active='$is_active' WHERE student_id='$student_id'";
		
		$result = $conn->query($query);
		if (!$result) die($conn->error);
		
		header("Location: student-list.php");
		
		exit;
	}
	
	$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Update Student</title>
		<style>
			body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
			}
			.container {
            background-color: #ffffff;
            padding: 20px;
            max-width: 400px;
            margin: 20px auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
			}
			h2 {
            text-align: center;
            color: #333;
			}
			form {
            display: flex;
            flex-direction: column;
			}
			label {
            margin-top: 10px;
			}
			input[type="text"],
			input[type="email"],
			input[type="number"],
			button {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
			}
			button {
            background-color: #0078d4;
            color: white;
            cursor: pointer;
            border: none;
            margin-top: 20px;
			}
			button:hover {
            background-color: #0056b3;
			}
			.header {
			width: 100%;
			padding: 10px;
			text-align: right;
			background-color: #f2f2f2;
			
		</style>
	</head>
	<body>
		
		<?php if (isset($row)): ?>
		
		<div class="header">
			<a href="logout.php">Logout</a> 
		</div>
		
		<div class="container">
			<h2>Update Student</h2>
			<form method="post" action="update-student.php">
				<input type="hidden" name="student_id" value="<?php echo htmlspecialchars($row['student_id']); ?>">
				
				<label for="student_id">Student ID</label>
				<input type="text" id="student_id" name="student_id" required value="<?php echo htmlspecialchars($row['student_id']); ?>">
				
				
				<label for="first_name">First Name</label>
				<input type="text" id="first_name" name="first_name" required value="<?php echo htmlspecialchars($row['first_name']); ?>">
				
				
				<label for="last_name">Last Name</label>
				<input type="text" id="last_name" name="last_name" required value="<?php echo htmlspecialchars($row['last_name']); ?>">
				
				<label for="phone_number">Phone Number</label>
				<input type="text" id="phone_number" name="phone_number" required value="<?php echo htmlspecialchars($row['phone_number']); ?>">
				
				<label for="address">Address</label>
				<input type="text" id="address" name="address" required value="<?php echo htmlspecialchars($row['address']); ?>">
				
				<label for="email">Email</label>
				<input type="text" id="email" name="email" required value="<?php echo htmlspecialchars($row['email']); ?>">
				
				<label for="gpa">GPA</label>
				<input type="text" id="gpa" name="gpa" required value="<?php echo htmlspecialchars($row['gpa']); ?>">
				
				<label for="major">Major</label>
				<input type="text" id="major" name="major" required value="<?php echo htmlspecialchars($row['major']); ?>">
				
				<label for="year">Year</label>
				<input type="text" id="year" name="year" required value="<?php echo htmlspecialchars($row['year']); ?>">
				
				<label for="enrollment_id">Enrollment ID</label>
				<input type="text" id="enrollment_id" name="enrollment_id" required value="<?php echo htmlspecialchars($row['enrollment_id']); ?>">
				
				<label for="advisor_id">Advisor ID</label>
				<input type="text" id="advisor_id" name="advisor_id" required value="<?php echo htmlspecialchars($row['advisor_id']); ?>">
				
				<label for="program_id">Program ID</label>
				<input type="text" id="program_id" name="program_id" required value="<?php echo htmlspecialchars($row['program_id']); ?>">
				
				<label for="is_active">Active</label>
				<input type="number" id="is_active" name="is_active" required value="<?php echo htmlspecialchars($row['is_active']); ?>">
				
				<button type="submit" name="update">Update</button>
			</form>
		</div>
		<?php else: ?>
		<p>Student data not found.</p>
		<?php endif; ?>
		
	</body>
</html>
