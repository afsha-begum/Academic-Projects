<?php
	$page_roles = array('admin', 'advisor');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
	
	$query = "SELECT * FROM faculty_course";
	$result = $conn->query($query);
	if (!$result) die("Database access failed: " . $conn->error);
	
	$rows = $result->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Faculty Course List</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
		<style>
			body {
            background-color: #f2f2f2;
            padding-top: 20px;
			}
			
			.container-fluid {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 20px;
			}
			
			.table-custom {
            margin-top: 20px;
			}
			
			.btn-custom {
            background-color: #007bff;
            border-color: #007bff;
            color: white;
			}
			
			.btn-custom:hover {
            background-color: #0056b3;
            border-color: #0056b3;
			}
			
			.table-full-width {
            min-width: 100%;
			}
			
			td, th {
            padding: .5rem;
			}
		</style>
	</style>
</head>
<body>
	
	<div class="container-fluid">
		<div class="row align-items-center justify-content-between">
			<div class="col-auto">
				<a href="admin-portal.php" class="btn btn-custom">
					&larr; Back to Admin Portal
				</a>
			</div>
			
			<div class="col text-center">
				<h2>Faculty-Course List</h2>
			</div>
			
			<div class="col-auto">
				<a href="add-faculty-course.php" class="btn btn-custom">
					Add Faculty-Course
				</a>
			</div>
			<div class="col-auto">
				<a href="logout.php" class="btn btn-custom">Logout</a> 
			</div>
		</div>
		
		<div class="table-responsive">
			<table class="table table-bordered table-custom">
				<thead>
					<tr>
						<th>Faculty Course ID</th>
						<th>Faculty ID</th>
						<th>Course ID</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
					<?php
						while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
							echo "<tr>";
							echo "<td>{$row['faculty_course_id']}</td>";
							echo "<td>{$row['faculty_id']}</td>";
							echo "<td>{$row['course_id']}</td>";
							echo "<td>
                            <div class='d-flex justify-content-start'>
							<a href='update-faculty-course.php?faculty_course_id={$row['faculty_course_id']}' class='btn btn-custom me-2'>Update</a>
							<form action='delete-faculty-course.php' method='post'>
							<input type='hidden' name='delete' value='yes'>
							<input type='hidden' name='faculty_course_id' value='{$row['faculty_course_id']}'>
							<input type='submit' value='Delete' class='btn btn-custom'>
							</form>
                            </div>
							</td>";
							echo "</tr>";
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
	
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js.bootstrap.bundle.min.js"></script>
</body>
</html>