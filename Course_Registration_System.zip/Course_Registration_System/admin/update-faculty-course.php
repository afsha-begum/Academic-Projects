<?php
	$page_roles = array('admin','advisor');
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
	
	$faculty_course_id = $faculty_id = $course_id = '';
	$row = null;
	
	if (isset($_GET['faculty_course_id'])) {
		$faculty_course_id = $conn->real_escape_string($_GET['faculty_course_id']);
		$query = "SELECT * FROM faculty_course WHERE faculty_course_id='$faculty_course_id'";
		$result = $conn->query($query);
		
		if (!$result) die($conn->error);
		$row = $result->fetch_array(MYSQLI_ASSOC);
		} elseif (isset($_POST['update'])) {
		$faculty_course_id = $conn->real_escape_string($_POST['faculty_course_id']);
		$faculty_id = $conn->real_escape_string($_POST['faculty_id']);
		$course_id = $conn->real_escape_string($_POST['course_id']);
		
		$query = "UPDATE faculty_course SET faculty_id='$faculty_id', course_id='$course_id' WHERE faculty_course_id='$faculty_course_id'";
		
		$result = $conn->query($query);
		if (!$result) die($conn->error);
		
		header("Location: faculty-course-list.php");
		exit;
	}
	
	$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Update Faculty Course</title>
		<style>
			body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
			}
			.container {
            background-color: #ffffff;
            padding: 20px;
            max-width: 400px;
            margin: 20px auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
			}
			h2 {
            text-align: center;
            color: #333;
			}
			form {
            display: flex;
            flex-direction: column;
			}
			label {
            margin-top: 10px;
			}
			input[type="text"],
			input[type="email"],
			input[type="number"],
			button {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
			}
			button {
            background-color: #0078d4;
            color: white;
            cursor: pointer;
            border: none;
            margin-top: 20px;
			}
			button:hover {
            background-color: #0056b3;
			}
			.header {
			width: 100%;
			padding: 10px;
			text-align: right;
			background-color: #f2f2f2;
			}
		</style>
	</head>
	<body>
		
		<div class="header">
			<a href="logout.php" class="logout-link">Logout</a> 
		</div>
		
		<?php if (isset($row)): ?>
		<div class="container">
			<h2>Update Faculty Course</h2>
			<form method="post" action="update-faculty-course.php">
				<input type="hidden" name="faculty_course_id" value="<?php echo htmlspecialchars($faculty_course_id); ?>">
				
				<label for="faculty_id">Faculty ID</label>
				<input type="text" id="faculty_id" name="faculty_id" required value="<?php echo htmlspecialchars($row['faculty_id']); ?>">
				
				<label for="course_id">Course ID</label>
				<input type="text" id="course_id" name="course_id" required value="<?php echo htmlspecialchars($row['course_id']); ?>">
				
				
				<button type="submit" name="update">Update</button>
			</form>
		</div>
		<?php else: ?>
		<p>Faculty Course data not found.</p>
		<?php endif; ?>
		
	</body>
</html>
