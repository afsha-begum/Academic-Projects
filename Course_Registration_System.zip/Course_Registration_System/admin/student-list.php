<?php
	$page_roles = array('admin');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
	
	$query = "SELECT * FROM student";
	$result = $conn->query($query);
	if (!$result) die("Database access failed: " . $conn->error);
	
	$rows = $result->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Student List</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
		<style>
			body {
            background-color: #f2f2f2;
            padding-top: 20px;
			}
			
			.container-fluid {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 20px;
			}
			
			.table-custom {
            margin-top: 20px;
			}
			
			.btn-custom {
            background-color: #007bff;
            border-color: #007bff;
            color: white;
			}
			
			.btn-custom:hover {
            background-color: #0056b3;
            border-color: #0056b3;
			}
			
			.table-full-width {
            min-width: 100%;
			}
			
			td, th {
            padding: .5rem;
			}
		</style>
	</head>
	<body>
		
		<div class="container-fluid">
			<div class="row align-items-center justify-content-between">
				<div class="col-auto">
					<a href="admin-portal.php" class="btn btn-custom">
						&larr; Back to Admin Portal
					</a>
				</div>
				
				<div class="col text-center">
					<h2>Student List</h2>
				</div>
				
				<div class="col-auto">
					<a href="add-student.php" class="btn btn-custom">
						Add New Student
					</a>
				</div>
				
				<div class="col-auto">
					<a href="logout.php" class="btn btn-custom">Logout</a> 
				</div>
				
				
			</div>
			
			<div class="table-responsive">
				<table class="table table-bordered table-custom">
					<thead>
						<tr>
							<th>Student ID</th>
							<th>First Name</th>
							<th>Last Name</th>
							<th>Phone Number</th>
							<th>Address</th>
							<th>Email</th>
							<th>GPA</th>
							<th>Major</th>
							<th>Year</th>
							<th>Enrollment ID</th>
							<th>Advisor ID</th>
							<th>Program ID</th>
							<th>Active</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>
						<?php
							while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
								echo "<tr>";
								echo "<td>{$row['student_id']}</td>";
								echo "<td>{$row['first_name']}</td>";
								echo "<td>{$row['last_name']}</td>";
								echo "<td>{$row['phone_number']}</td>";
								echo "<td>{$row['address']}</td>";
								echo "<td>{$row['email']}</td>";
								echo "<td>{$row['gpa']}</td>";
								echo "<td>{$row['major']}</td>";
								echo "<td>{$row['year']}</td>";
								echo "<td>{$row['enrollment_id']}</td>";
								echo "<td>{$row['advisor_id']}</td>";
								echo "<td>{$row['program_id']}</td>";
								echo "<td>{$row['is_active']}</td>";
								echo "<td>
								<div class='d-flex justify-content-start'>
                                <a href='update-student.php?student_id={$row['student_id']}' class='btn btn-custom me-2'>Update</a>
                                <form action='inactivate-student.php' method='post'>
								<input type='hidden' name='student_id' value='{$row['student_id']}'>
								<input type='submit' name='inactivate' value='Inactivate' class='btn btn-custom'>
                                </form>
								</div>
								</td>";
								echo "</tr>";
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
		
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
	</body>
</html>
