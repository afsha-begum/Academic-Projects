<?php
	
	$page_roles = array('admin');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Admin Portal</title>
		<style>
			body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
			background-color: #f2f2f2;
			}
			.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 10px 20px;
			background-color: #fff;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
			}
			.logo {
			height: 50px;
			}
			.admin-portal {
			font-size: 1.2em;
			color: #333;
			}
			.navigation {
			display: grid;
			grid-template-columns: repeat(4, 1fr);
			gap: 20px;
			padding: 20px;
			max-width: 1000px;
			margin: 40px auto;
			background-color: #fff;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
			border-radius: 8px;
			}
			.nav-link {
			padding: 10px 15px;
			text-align: center;
			background-color: #007bff;
			color: white;
			text-decoration: none;
			border: none;
			border-radius: 4px;
			transition: background-color 0.3s ease;
			}
			.nav-link:hover {
			background-color: #0056b3;
			}
			.footer {
			text-align: center;
			padding: 20px;
			background-color: #fff;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
			position: fixed;
			bottom: 0;
			width: 100%;
			}
		</style>
	</head>
	<body>
		
		<div class="header">
			<img src="logo.jpg" alt="INTI Logo" class="logo">
			<div class="admin-portal">Admin Portal</div>
			<a href="logout.php">Logout</a>
		</div>
		
		<div class="navigation">
			<a href="student-list.php" class="nav-link">Student List</a>
			<a href="advisor-list.php" class="nav-link">Advisor List</a>
			<a href="faculty-list.php" class="nav-link">Faculty List</a>
			<a href="course-list.php" class="nav-link">Course List</a>
			<a href="semester-list.php" class="nav-link">Semester List</a>
			<a href="enrollment-list.php" class="nav-link">Enrollment List</a>
			<a href="prerequisite-list.php" class="nav-link">Prerequisite List</a>
			<a href="program-list.php" class="nav-link">Program List</a>
			<a href="faculty-course-list.php" class="nav-link">Faculty-Course List</a>
			<a href="student-report-list.php" class="nav-link">Student List Report</a>
			<a href="course-enrollment-list.php" class="nav-link">Course Enrollment Report</a>
			
			
		</div>
		
		<div class="footer">
			<p>&copy; 2023 INTI College. All rights reserved.</p>
		</div>
		
	</body>
</html>

