<?php
session_start(); 

require_once 'db-info.php';
require_once 'user.php'; 

$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['user-type'])) {
        $userType = $_POST['user-type'];
        
    
        $tmp_username = mysql_entities_fix_string($conn, $_POST['username']);
        $tmp_password = mysql_entities_fix_string($conn, $_POST['password']);

 
        $query = "SELECT password FROM users WHERE username = '$tmp_username'";
        $result = $conn->query($query);
        
        if (!$result) die($conn->error);

        $rows = $result->num_rows;
        $passwordFromDB = "";

        for ($j = 0; $j < $rows; $j++) {
            $result->data_seek($j);
            $row = $result->fetch_array(MYSQLI_ASSOC);
            $passwordFromDB = $row['password'];
        }

 
        if (password_verify($tmp_password, $passwordFromDB)) {
            $user = new User($tmp_username);
            $_SESSION['user'] = $user;

          
            switch ($userType) {
                case 'student':
                    header("Location: student-portal.php");
                    break;
                case 'advisor':
                    header("Location: advisor-portal.php");
                    break;
                case 'admin':
                    header("Location: admin-portal.php");
                    break;
                default:
                   
                    break;
            }
            exit();
        } else {
            echo "login error<br>";
        }
    }
}

$conn->close();

// Sanitization functions
function mysql_entities_fix_string($conn, $string) {
    return htmlentities(mysql_fix_string($conn, $string));
}

function mysql_fix_string($conn, $string) {
    $string = stripslashes($string);
    return $conn->real_escape_string($string);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
    }

    #logo {
        text-align: center;
    }

    #login-container {
        background-color: #ffffff;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        padding: 20px;
        width: 300px;
        margin-top: 20px;
    }

    #login-form {
        text-align: center;
    }

    #login-heading {
        font-size: 24px;
        margin-bottom: 10px;
    }

    input[type="text"],
    input[type="password"] {
        width: 100%;
        padding: 10px;
        margin: 5px 0;
        border: 1px solid #ccc;
        border-radius: 3px;
    }

    #user-type {
        text-align: center;
        margin-bottom: 10px;
    }

    #create-account,
    #forgot-password {
        margin-bottom: 10px;
        text-align: center;
    }

    #create-account a,
    #forgot-password a {
        cursor: pointer;
        color: #0078d4;
        margin-top: 10px;
    }

    #create-account {
        float: left;
        margin-right: 5px;
    }

    #forgot-password {
        float: right;
        margin-left: 5px;
    }

    #login-button {
        background-color: #0078d4;
        color: #fff;
        padding: 10px 0;
        border: none;
        border-radius: 3px;
        cursor: pointer;
        width: 100%;
        margin-top: 10px;
    }

    #login-button:hover {
        background-color: #0056b3;
    }
</style>

    <script>
	function updateAndRedirect(userType) {
		switch (userType) {
			case 'student':
				window.location.href = 'create-student-account.php';
				break;
			case 'advisor':
				window.location.href = 'create-advisor-account.php';
				break;
			case 'admin':
				window.location.href = 'create-admin-account';
				break;
			default:
				break;
		}
	}

	function getSelectedUserType() {
		var radios = document.getElementsByName('user-type');
		for (var i = 0; i < radios.length; i++) {
			if (radios[i].checked) {
				return radios[i].value;
			}
		}
		return 'student';
	}
    </script>
</head>
<body>
    <div id="logo">
        <img src="logo.jpg" alt="INTI Logo" width="100" height="100">
    </div>
    <div id="login-container">
        <form method='post' action='login.php'>
            <h2 id="login-heading">Login</h2>
            <div id="user-type">
                <label for="student">Student</label>
                <input type="radio" id="student" name="user-type" value="student" checked>
                <label for="advisor">Advisor</label>
                <input type="radio" id="advisor" name="user-type" value="advisor">
                <label for="admin">Admin</label>
                <input type="radio" id="admin" name="user-type" value="admin">
            </div>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
            <br>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
            <div id="create-account">
				<a href="#" onclick="updateAndRedirect(getSelectedUserType());">Create Account</a>
			</div>
            <div id="forgot-password">
                <a href="#">Forgot Password</a>
            </div>
            <br>
            <button type="submit" id="login-button">Login</button>
        </form>
    </div>
    <input type="hidden" id="user-type-create" name="user-type" value="student">
</body>
</html>


