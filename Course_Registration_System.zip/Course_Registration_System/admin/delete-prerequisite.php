<?php
	
	$page_roles = array('admin', 'advisor');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die($conn->connect_error);
	
	
	if (isset($_POST['delete'])) {
		$prerequisite_id = $_POST['prerequisite_id'];
		
		
		$query = "DELETE FROM prerequisite WHERE prerequisite_id='$prerequisite_id'";
		
		
		$result = $conn->query($query);
		if (!$result) die($conn->error);
		
		header("Location: prerequisite-list.php"); 
		exit;
	}
	
	// Close the database connection
	$conn->close();
?>
