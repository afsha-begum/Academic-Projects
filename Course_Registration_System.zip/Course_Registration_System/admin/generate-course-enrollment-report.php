<?php
	$page_roles = array('admin', 'advisor');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Course Enrollment Report</title>
		<style>
			
			body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 20px;
			}
			.header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 100%;
			}
			.footer {
            text-align: center;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            position: fixed;
            bottom: 0;
            width: 100%;
			}
			table {
            margin-top: 20px;
            border-collapse: collapse;
            width: 100%;
			}
			th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
			}
			th {
            background-color: #007bff;
            color: white;
			}
		</style>
	</head>
	<body>
		
		<div class="header">
			<img src="logo.jpg" alt="INTI logo" height="50" width="50" class="logo">
			<div class="admin-name">Admin Name</div>
		</div>
		
		<?php
			
			if (isset($_POST['semester_id'])) {
				$semesterId = $_POST['semester_id'];
				
				
				$sql = "SELECT 
                c.course_id, 
                c.course_name, 
                COUNT(e.enrollment_id) AS enrollment_count,
                s.year AS semester_year
				FROM 
                course c
				JOIN 
                enrollment e ON c.course_id = e.course_id
				JOIN 
                semester s ON c.semester_id = s.semester_id
				WHERE 
                s.semester_id = ?
				GROUP BY 
                c.course_id, c.course_name, s.year
				ORDER BY 
                c.course_id;";
				
				
				$stmt = $conn->prepare($sql);
				if (!$stmt) {
					die("Prepare failed: " . $conn->error);
				}
				
				
				$stmt->bind_param("i", $semesterId);
				
				
				if (!$stmt->execute()) {
					die("Execute failed: " . $stmt->error);
				}
				
				
				$result = $stmt->get_result();
				
				
				if ($result->num_rows > 0) {
					echo "<h2>Course Enrollment Report</h2>";
					echo "<table>
					<tr>
                    <th>Course ID</th>
                    <th>Course Name</th>
                    <th>Enrollment Count</th>
                    <th>Semester Year</th>
					</tr>";
					
					while ($row = $result->fetch_assoc()) {
						echo "<tr>
						<td>{$row['course_id']}</td>
						<td>{$row['course_name']}</td>
						<td>{$row['enrollment_count']}</td>
						<td>{$row['semester_year']}</td>
						</tr>";
					}
					echo "</table>";
					} else {
					echo "<p>No results found for the specified semester.</p>";
				}
				} else {
				echo "<p>Please provide a semester ID.</p>";
			}
		?>
		
		<div class="footer">
			<p>&copy; 2023 INTI College. All rights reserved.</p>
		</div>
		
	</body>
</html>
<?php
	
	$conn->close();
?>
