<!DOCTYPE html>
<html>
<head>
  <title>INTI College</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- Embedded CSS Styles -->
  <style>
    body {
      padding-top: 56px;
    }

    .navbar {
      margin-bottom: 20px;
    }

    .jumbotron {
      background: #007bff;
      color: #fff;
    }

    .why-inti-section {
      padding: 40px 0;
    }

    .btn-learn-more {
      background-color: #f8f9fa; 
      border-color: #343a40;
    }

    footer {
      padding: 20px 0;
      margin-top: 20px;
    }

    footer a {
      color: #343a40;
    }

    footer a:hover {
      color: #343a40;
    }
  </style>
</head>
<body>

<!-- Navigation bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<div class="container">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">HOME</a>
      </li>
      <li class="nav-item mx-3">
        <a class="nav-link" href="#">ABOUT US</a>
      </li>
      <li class="nav-item mx-3">
        <a class="nav-link" href="#">ACADEMICS</a>
      </li>
      <li class="nav-item mx-3">
        <a class="nav-link" href="#">ADMISSIONS</a>
      </li>
      <li class="nav-item mx-3">
        <a class="nav-link" href="#">APPLY</a>
      </li>
      <li class="nav-item active mx-3">
        <a class="nav-link" href="setupusers.php">LOGIN</a>
      </li>
    </ul>
  </div>
  </div>
</nav>

<!-- Header Section -->
<section class="welcome-section">
  <div class="jumbotron jumbotron-fluid">
    <div class="container text-center">
      <h1 class="display-4">Welcome to INTI College</h1>
      <p class="lead">Your journey to excellence begins here</p>
    </div>
  </div>
</section>

<!-- Why INTI Section -->
<section class="why-inti-section">
  <div class="container">
    <h2>Why INTI?</h2>
    <p>Choosing INTI College for your education journey means becoming a part of a community that is dedicated to unlocking potential and fostering innovation. At INTI, we provide more than just academic excellence; we offer a holistic educational experience that prepares you for the real world. Our state-of-the-art facilities, dedicated faculty, and strong industry partnerships ensure that you receive an education that is relevant, practical, and in line with the latest global trends. Our commitment to student success is evident through our comprehensive support services and a vibrant campus life that promotes personal growth. By embracing diversity and promoting international collaboration, INTI empowers you to start your future on a global stage. Join us to experience a learning culture where ideas thrive and futures are born.</p>
    <button type="button" class="btn btn-learn-more">Learn More</button>
  </div>
</section>

<!-- Footer -->
<footer class="footer bg-light">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-6 mb-4 mb-lg-0">
        <h5>Contact Us</h5>
        <ul class="list-unstyled mb-0">
          <li><a href="#">123 College St, City, Country</a></li>
          <li><a href="mailto:info@inticollege.edu">info@inticollege.edu</a></li>
          <li><a href="#">+1 234 567 8900</a></li>
        </ul>
      </div>
      
      <div class="col-lg-4 col-md-6 mb-4 mb-lg-0">
        <h5>Resources</h5>
        <ul class="list-unstyled mb-0">
          <li><a href="#">Faculty</a></li>
          <li><a href="#">Students</a></li>
          <li><a href="#">Alumni</a></li>
          <li><a href="#">Events</a></li>
          <li><a href="#">Information Request</a></li>
        </ul>
      </div>

      <div class="col-lg-4 col-md-6 mb-lg-0">
        <h5>Follow Us</h5>
        <ul class="list-unstyled mb-0">
          <li><a href="#"><i class="facebook"></i> Facebook</a></li>
          <li><a href="#"><i class="twitter"></i> Twitter</a></li>
          <li><a href="#"><i class="instagram"></i> Instagram</a></li>
          <li><a href="#"><i class="linkedin-in"></i> LinkedIn</a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>

</body>
</html>
