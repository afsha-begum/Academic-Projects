<?php
	$page_roles = array('admin', 'advisor');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Course Enrollment List</title>
		<style>
			
			body {
			font-family: Arial, sans-serif;
			background-color: #f2f2f2;
			margin: 0;
			padding: 20px;
			display: flex;
			flex-direction: column;
			align-items: center;
			}
			.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 10px 20px;
			background-color: #fff;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
			width: 100%;
			}
			.footer {
			text-align: center;
			padding: 20px;
			background-color: #fff;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
			position: fixed;
			bottom: 0;
			width: 100%;
			}
			form {
			background-color: #fff;
			padding: 20px;
			margin-top: 20px;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
			border-radius: 8px;
			}
			label, input {
			display: block;
			width: 100%;
			margin-bottom: 15px;
			}
			input[type="submit"] {
			background-color: #007bff;
			color: white;
			padding: 10px;
			border: none;
			border-radius: 4px;
			cursor: pointer;
			}
			input[type="submit"]:hover {
			background-color: #0056b3;
			}
		</style>
	</head>
	<body>
		
		<div class="header">
			<img src="logo.jpg" alt="INTI logo" height="50" width="50" class="logo">
			<div class="admin-portal">Admin Portal</div>
			<a href="logout.php">Logout</a>
		</div>
		
		<h2>Course Enrollment List</h2>
		
		<form action="generate-course-enrollment-report.php" method="post">
			<label for="semester_id">Enter Semester ID:</label>
			<input type="number" name="semester_id" id="semester_id" placeholder="Enter Semester ID" required>
			
			<input type="submit" value="Generate Report">
		</form>
		
		<div class="footer">
			<p>&copy; 2023 INTI College. All rights reserved.</p>
		</div>
		
	</body>
</html>

