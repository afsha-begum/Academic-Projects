<?php
	
	$page_roles = array('admin', 'advisor');
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die($conn->connect_error);
	
	
	if (isset($_POST['delete'])) {
		$enrollment_id = $_POST['enrollment_id'];
		
		
		$query = "DELETE FROM enrollment WHERE enrollment_id= '$enrollment_id'";
		
		
		$result = $conn->query($query);
		if (!$result) die($conn->error);
		
		
		header("Location: enrollment-list.php"); 
		exit;
	}
	
	
	$conn->close();
?>
