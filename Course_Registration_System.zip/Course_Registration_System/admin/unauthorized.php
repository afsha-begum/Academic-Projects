<?php

echo "You are not authorized to view this page<br>";






?>