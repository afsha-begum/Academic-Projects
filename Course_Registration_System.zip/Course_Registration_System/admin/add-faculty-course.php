<?php
	$page_roles = array('admin', 'advisor');
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
	
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		
		$faculty_id = $conn->real_escape_string($_POST['faculty_id']);
		$course_id = $conn->real_escape_string($_POST['course_id']);
		
		
		$query = "INSERT INTO faculty_course (faculty_id, course_id) VALUES ('$faculty_id', '$course_id')";
		
		$result = $conn->query($query);
		if (!$result) die("Database access failed: " . $conn->error);
		
		header("Location: faculty-course-list.php");
		exit;
	}
	
	$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Add Faculty Course</title>
		<style>
			body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
			}
			.container {
            background-color: #ffffff;
            padding: 20px;
            max-width: 400px;
            margin: 20px auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
			}
			h2 {
            text-align: center;
            color: #333;
			}
			form {
            display: flex;
            flex-direction: column;
			}
			label {
            margin-top: 10px;
			}
			input[type="text"],
			input[type="number"],
			button {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 90%;
			}
			button {
            background-color: #0078d4;
            color: white;
            cursor: pointer;
            border: none;
            margin-top: 20px;
			}
			button:hover {
            background-color: #0056b3;
			}
			.header {
			width: 100%;
			padding: 10px;
			text-align: right;
			background-color: #f2f2f2;
			}
		</style>
	</head>
	<body>
		
		<div class="header">
			<a href="logout.php" class="logout-link">Logout</a> 
		</div>
		
		<div class="container">
			<h2>Add Faculty Course</h2>
			<form method="post" action="add-faculty-course.php">
				
				<label for="faculty_id">Faculty ID</label>
				<input type="text" id="faculty_id" name="faculty_id" required>
				
				<label for="course_id">Course ID</label>
				<input type="text" id="course_id" name="course_id" required>
				
				<button type="submit">Add</button>
			</form>
		</div>
		
	</body>
</html>
