<?php
	
	$page_roles = array('admin');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
	
	
	if (isset($_POST['inactivate'])) {
		$student_id = $_POST['student_id'];
		
		// Validate the input
		if (!filter_var($student_id, FILTER_VALIDATE_INT)) {
			die("Invalid student ID");
		}
		
		// UPDATE query to set 'is_active' to 0 (false)
		$stmt = $conn->prepare("UPDATE student SET is_active = 0 WHERE student_id = ?");
		if (!$stmt) die("Prepare statement failed: " . $conn->error);
		
		
		$stmt->bind_param("i", $student_id);
		if (!$stmt->execute()) die("Execute failed: " . $stmt->error);
		
		
		if ($stmt->affected_rows > 0) {
			
			header("Location: student-list.php");
			exit;
			} else {
			echo "No student was inactivated (perhaps the student was already inactive or doesn't exist).";
		}
		
		
		$stmt->close();
	}
	
	
	$conn->close();
?>
