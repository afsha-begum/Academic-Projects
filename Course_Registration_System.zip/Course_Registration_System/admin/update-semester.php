<?php
	$page_roles = array('admin');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die($conn->connect_error);
	
	if (isset($_GET['semester_id'])) {
		$semester_id = $conn->real_escape_string($_GET['semester_id']);
		$query = "SELECT * FROM semester WHERE semester_id='$semester_id'";
		$result = $conn->query($query);
		
		if (!$result) die($conn->error);
		$row = $result->fetch_array(MYSQLI_ASSOC);
		} elseif (isset($_POST['update'])) {
		$semester_id = $conn->real_escape_string($_POST['semester_id']);
		$status = $conn->real_escape_string($_POST['status']);
		$year = $conn->real_escape_string($_POST['year']);
		$program_id = $conn->real_escape_string($_POST['program_id']);
		$is_active = $conn->real_escape_string($_POST['is_active']);
		$query = "UPDATE semester SET status='$status', year='$year', program_id='$program_id', is_active='$is_active' WHERE semester_id='$semester_id'";
		
		$result = $conn->query($query);
		if (!$result) die($conn->error);
		
		header("Location: semester-list.php");
		exit;
	}
	
	$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Update Semester</title>
		<style>
			body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
			}
			.container {
            background-color: #ffffff;
            padding: 20px;
            max-width: 400px;
            margin: 20px auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
			}
			h2 {
            text-align: center;
            color: #333;
			}
			form {
            display: flex;
            flex-direction: column;
			}
			label {
            margin-top: 10px;
			}
			input[type="text"],
			input[type="email"],
			input[type="number"],
			button {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
			}
			button {
            background-color: #0078d4;
            color: white;
            cursor: pointer;
            border: none;
            margin-top: 20px;
			}
			button:hover {
            background-color: #0056b3;
			}
			.header {
			width: 100%;
			padding: 10px;
			text-align: right;
			background-color: #f2f2f2;
			}
		</style>
	</head>
	<body>
		
		<div class="header">
			<a href="logout.php" class="logout-link">Logout</a> 
		</div>
		
		<?php if (isset($row)): ?>
		<div class="container">
			<h2>Update Semester</h2>
			<form method="post" action="update-semester.php">
				<input type="hidden" name="semester_id" value="<?php echo htmlspecialchars($row['semester_id']); ?>">
				
				
				<label for="status">Status</label>
				<input type="text" id="status" name="status" required value="<?php echo htmlspecialchars($row['status']); ?>">
				
				
				<label for="year">Year</label>
				<input type="text" id="year" name="year" required value="<?php echo htmlspecialchars($row['year']); ?>">
				
				
				<label for="program_id">Program ID</label>
				<input type="text" id="program_id" name="program_id" required value="<?php echo htmlspecialchars($row['program_id']); ?>">
				
				
				<label for="is_active">Active</label>
				<input type="number" id="is_active" name="is_active" required value="<?php echo htmlspecialchars($row['is_active']); ?>">
				
				<button type="submit" name="update">Update</button>
			</form>
		</div>
		<?php else: ?>
		<p>Semester data not found.</p>
		<?php endif; ?>
		
	</body>
</html>

