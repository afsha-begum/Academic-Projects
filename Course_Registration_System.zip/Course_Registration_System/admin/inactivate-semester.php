<?php
	
	$page_roles = array('admin');
	
	require_once 'db-info.php';
	require_once 'checksession.php';
	
	
	$conn = new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
	
	
	if (isset($_POST['inactivate'])) {
		$semester_id = $_POST['semester_id'];
		
		
		if (!filter_var($semester_id, FILTER_VALIDATE_INT)) {
			die("Invalid semester ID");
		}
		
		
		$stmt = $conn->prepare("UPDATE semester SET is_active = 0 WHERE semester_id = ?");
		if (!$stmt) die("Prepare statement failed: " . $conn->error);
		
		
		$stmt->bind_param("i", $semester_id);
		if (!$stmt->execute()) die("Execute failed: " . $stmt->error);
		
		
		if ($stmt->affected_rows > 0) {
			
			header("Location: semester-list.php");
			exit;
			} else {
			echo "No semester was inactivated (perhaps the semester was already inactive or doesn't exist).";
		}
		
		
		$stmt->close();
	}
	
	
	$conn->close();
?>
