
<?php
$page_roles = array('advisor');
require_once 'db-info.php';
require_once 'checksession.php';


$conn = new mysqli($hn, $un, $pw, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['gpa']) && isset($_POST['course_name'])) {
    $gpa = $_POST['gpa'];
    $courseName = $_POST['course_name'];

    $sql = "SELECT s.student_id
            FROM student s
            INNER JOIN enrollment e ON s.student_id = e.student_id
            INNER JOIN course c ON e.course_id = c.course_id
            WHERE s.gpa >= ? AND c.course_name = ?";

    $statement = $conn->prepare($sql);

    if (!$statement) {
        die("Prepare failed: " . $conn->error);
    }

    $statement->bind_param("ss", $gpa, $courseName);

    if (!$statement->execute()) {
        die("Execute failed: " . $statement->error);
    }

    $result = $statement->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fetch Student Details</title>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 20px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 100%;
        }
        .footer {
            text-align: center;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        table {
            margin-top: 20px;
            border-collapse: collapse;
            width: 10%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>

<div class="header">
<img src="logo.jpg" alt="INTI Logo" width="50" height="50" class="logo">
    <div>Advisor Portal</div>
</div>

<?php
  if ($result->num_rows > 0) {
    echo "<h2 style='text-align: center;'>Student Details</h2>";
    echo "<table style='margin: 0 auto;'>
            <tr>
                <th>Student ID</th>
            </tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td style='text-align: center;'>{$row['student_id']}</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<p style='text-align: center;'>No results found for the specified criteria.</p>";
}

?>

<div class="footer">
    <p>&copy; 2023 Your College. All rights reserved.</p>
</div>

</body>
</html>
<?php
} else {
    echo "Please provide GPA and course name information.";
}

$conn->close();
?>
