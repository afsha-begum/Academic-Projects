<?php
$page_roles = array('advisor');
require_once 'db-info.php';
require_once 'checksession.php';


$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);

if (isset($_GET['program_id'])) {
    $program_id = $conn->real_escape_string($_GET['program_id']);
    $query = "SELECT * FROM program WHERE program_id='$program_id'";
    $result = $conn->query($query);

    if (!$result) die($conn->error);
    $row = $result->fetch_array(MYSQLI_ASSOC);
} elseif (isset($_POST['update'])) {
    $program_id = $conn->real_escape_string($_POST['program_id']);
    $name = $conn->real_escape_string($_POST['name']);
    $type = $conn->real_escape_string($_POST['type']);
    $department = $conn->real_escape_string($_POST['department']);
    $query = "UPDATE program SET name='$name', type='$type', department='$department' WHERE program_id='$program_id'";

    $result = $conn->query($query);
    if (!$result) die($conn->error);

    header("Location: program-list.php");
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<p style="text-align: right; margin-top: 20px;">
        <a href="logout.php">Logout</a>
</p>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Program</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }
        .container {
            background-color: #ffffff;
            padding: 20px;
            max-width: 400px;
            margin: 20px auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
        }
        input[type="text"],
        input[type="email"],
        input[type="number"],
        button {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #0078d4;
            color: white;
            cursor: pointer;
            border: none;
            margin-top: 20px;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<?php if (isset($row)): ?>
<div class="container">
    <h2>Update Program</h2>
    <form method="post" action="update-program.php">
        <input type="hidden" name="program_id" value="<?php echo htmlspecialchars($row['program_id']); ?>">

       
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required value="<?php echo htmlspecialchars($row['name']); ?>">

     
		<label for="type">Year</label>
        <input type="text" id="type" name="type" required value="<?php echo htmlspecialchars($row['type']); ?>">
		
		
		<label for="department">Department</label>
        <input type="text" id="department" name="department" required value="<?php echo htmlspecialchars($row['department']); ?>">
		

        <button type="submit" name="update">Update</button>
    </form>
</div>
<?php else: ?>
<p>Semester data not found.</p>
<?php endif; ?>

</body>
</html>


    
       