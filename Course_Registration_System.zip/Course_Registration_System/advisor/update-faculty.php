<?php

$page_roles = array('advisor');
require_once 'db-info.php';
require_once 'checksession.php';


$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$faculty_course_id = $faculty_id = $course_id = '';
$row = null; 

if (isset($_GET['faculty_course_id'])) {
    $faculty_course_id = $conn->real_escape_string($_GET['faculty_course_id']);
    $query = "SELECT * FROM faculty_course WHERE faculty_course_id='$faculty_course_id'";
    $result = $conn->query($query);

    if (!$result) die($conn->error);
    $row = $result->fetch_array(MYSQLI_ASSOC);

    
    $faculty_course_id = $row['faculty_course_id'];
    $faculty_id = $row['faculty_id'];
    $course_id = $row['course_id'];
} elseif (isset($_POST['update'])) {
    $faculty_course_id = $conn->real_escape_string($_POST['faculty_course_id']);
    $faculty_id = $conn->real_escape_string($_POST['faculty_id']);
    $course_id = $conn->real_escape_string($_POST['course_id']);

    
    $query = "UPDATE faculty_course SET faculty_id='$faculty_id', course_id='$course_id' WHERE faculty_course_id='$faculty_course_id'";
    
    $result = $conn->query($query);
    if (!$result) die($conn->error);

    header("Location: course-assignment-list.php");
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<p style="text-align: right; margin-top: 20px;">
        <a href="logout.php">Logout</a>
</p>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Prerequisite</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }
        .container {
            background-color: #ffffff;
            padding: 20px;
            max-width: 400px;
            margin: 20px auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
        }
        input[type="text"],
        input[type="email"],
        input[type="number"],
        button {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #0078d4;
            color: white;
            cursor: pointer;
            border: none;
            margin-top: 20px;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Update Faculty</h2>
    <form method="post" action="update-faculty.php">
        
        <label for="faculty_course_id">Faculty Course ID</label>
        <input type="text" id="faculty_course_id" name="faculty_course_id" value="<?php echo isset($row['faculty_course_id']) ? htmlspecialchars($row['faculty_course_id']) : ''; ?>" required>
		
        <label for="faculty_id">Faculty ID</label>
        <input type="text" id="faculty_id" name="faculty_id" value="<?php echo isset($row['faculty_id']) ? htmlspecialchars($row['faculty_id']) : ''; ?>" required>
        
        <label for="course_id">Course ID</label>
        <input type="text" id="course_id" name="course_id" value="<?php echo isset($row['course_id']) ? htmlspecialchars($row['course_id']) : ''; ?>" required>
        
        <button type="submit" name="update">Update</button>
    </form>
</div>

</body>
</html>
