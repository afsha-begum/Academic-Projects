<?php
$page_roles = array('advisor');
require_once 'db-info.php';
require_once 'checksession.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $enrollmentID = $_POST["enrollmentID"];
    $enrollmentDate = $_POST["enrollmentDate"];
    $enrollmentStatus = $_POST["enrollmentStatus"];
    $grade = $_POST["grade"];
     


    $conn = new mysqli($hn, $un, $pw, $db);

    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    
    $sql = "UPDATE enrollment SET
            enrollment_date = '$enrollmentDate',
            enrollment_status = '$enrollmentStatus',
            grade = '$grade'
            WHERE enrollment_id = '$enrollmentID'";

    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
    header("Location: enrollment-list.php");
    exit;
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<p style="text-align: right; margin-top: 20px;">
        <a href="logout.php">Logout</a>
</p>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Enrollment Details</title>
<style>
body {
  font-family: Arial, sans-serif;
  padding: 20px;
  background: #f0f0f0;
}

.form-container {
  background: #ffffff;
  padding: 20px;
  margin: 0 auto;
  width: 300px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
  text-align: center;
  color: #333;
  margin-bottom: 30px;
}

label, input {
  display: block;
  width: 100%;
  margin-bottom: 10px;
}

input[type="text"] {
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type="submit"] {
  padding: 10px;
  color: white;
  background: #007bff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type="submit"]:hover {
  background: #0056b3;
}
</style>
</head>
<body>

<div class="form-container">
  <h2>Update Student Enrollment Details</h2>
  <form action="#" method="post">
    <label for="enrollmentID">Enrollment ID</label>
    <input type="text" id="enrollmentID" name="enrollmentID">

    <label for="enrollmentDate">Enrollment Date</label>
    <input type="text" id="enrollmentDate" name="enrollmentDate">

    <label for="enrollmentStatus">Enrollment Status</label>
    <input type="text" id="enrollmentStatus" name="enrollmentStatus">

    <label for="grade">Grade</label>
    <input type="text" id="grade" name="grade">

    <input type="submit" value="Update">
  </form>
</div>

</body>
</html>
