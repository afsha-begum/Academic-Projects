<?php

$page_roles = array('advisor');
require_once 'db-info.php';
require_once 'checksession.php';



$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);


if (isset($_POST['delete'])) {
    $program_id = $_POST['program_id'];

    
    $query = "DELETE FROM program WHERE program_id='$program_id'";

    
    $result = $conn->query($query);
    if (!$result) die($conn->error);

    
    header("Location: program-list.php"); 
    exit;
}


$conn->close();
?>
