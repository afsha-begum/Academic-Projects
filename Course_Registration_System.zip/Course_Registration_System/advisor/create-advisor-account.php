<?php

require_once 'db-info.php';

$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $conn->real_escape_string($_POST['first_name']);
    $last_name = $conn->real_escape_string($_POST['last_name']);
    $email = $conn->real_escape_string($_POST['email']);
    

    $query = "INSERT INTO advisor (first_name, last_name,email) VALUES ('$first_name', '$last_name', '$email')";
    
    $result = $conn->query($query);
    if (!$result) die("Database access failed: " . $conn->error);


    $username = $conn->real_escape_string($_POST['username']);
    $password = $conn->real_escape_string($_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);


    $user_query = "INSERT INTO users (username, password, forename, surname) VALUES ('$username', '$hashed_password', '$first_name', '$last_name')";
    $user_result = $conn->query($user_query);
    if (!$user_result) die("Database access failed: " . $conn->error);
	
	$role_query = "INSERT INTO roles (username, role) VALUES ('$username', 'advisor')";
    $role_result = $conn->query($role_query);

    if (!$role_result) {
        die("Database access failed: " . $conn->error);
    }


    header("Location: login.php");
    exit;
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Student</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        padding: 20px;
    }
    #add-student-form {
        background-color: #ffffff;
        padding: 20px;
        width: 300px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        margin: auto;
        border-radius: 8px;
    }
    input[type="text"],
    input[type="email"],
    input[type="password"] {
        width: calc(100% - 22px);
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 3px;
    }
    input[type="submit"] {
        width: 100%;
        padding: 10px;
        border: none;
        background-color: #0078d4;
        color: white;
        border-radius: 3px;
        cursor: pointer;
    }
    input[type="submit"]:hover {
        background-color: #0056b3;
    }
</style>
</head>
<body>

<div id="add-student-form">
    <form method="post" action="create-advisor-account.php">
        <h2>Advisor</h2>
        <input type="text" name="first_name" placeholder="First Name" required>
        <input type="text" name="last_name" placeholder="Last Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" value="Add">
    </form>
</div>

</body>
</html>
