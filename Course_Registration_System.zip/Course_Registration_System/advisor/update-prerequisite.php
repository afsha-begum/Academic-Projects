<?php
$page_roles = array('advisor');
require_once 'db-info.php';
require_once 'checksession.php';


$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);

if (isset($_GET['prerequisite_id'])) {
    $prerequisite_id = $conn->real_escape_string($_GET['prerequisite_id']);
    $query = "SELECT * FROM prerequisite WHERE prerequisite_id='$prerequisite_id'";
    $result = $conn->query($query);

    if (!$result) die($conn->error);
    $row = $result->fetch_array(MYSQLI_ASSOC);
} elseif (isset($_POST['update'])) {
    $prerequisite_id = $conn->real_escape_string($_POST['prerequisite_id']);
    $course_id = $conn->real_escape_string($_POST['course_id']);
    $enrollment_id = $conn->real_escape_string($_POST['enrollment_id']);
    $prerequisite_course_id = $conn->real_escape_string($_POST['prerequisite_course_id']);
    $query = "UPDATE prerequisite SET course_id='$course_id', enrollment_id='$enrollment_id', prerequisite_course_id='$prerequisite_course_id' WHERE prerequisite_id='$prerequisite_id'";

    $result = $conn->query($query);
    if (!$result) die($conn->error);

    header("Location: prerequisite-list.php");
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<p style="text-align: right; margin-top: 20px;">
        <a href="logout.php">Logout</a>
</p>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Prerequisite</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }
        .container {
            background-color: #ffffff;
            padding: 20px;
            max-width: 400px;
            margin: 20px auto;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
        }
        input[type="text"],
        input[type="email"],
        input[type="number"],
        button {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #0078d4;
            color: white;
            cursor: pointer;
            border: none;
            margin-top: 20px;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<?php if (isset($row)): ?>
<div class="container">
    <h2>Update Prerequisite</h2>
    <form method="post" action="update-prerequisite.php">
        <input type="hidden" name="prerequisite_id" value="<?php echo htmlspecialchars($row['prerequisite_id']); ?>">
		
		<label for="prerequisite_id">Prerequisite ID</label>
        <input type="number" id="prerequisite_id" name="prerequisite_id" required value="<?php echo htmlspecialchars($row['prerequisite_id']); ?>">

       
        <label for="course_id">Course ID</label>
        <input type="number" id="course_id" name="course_id" required value="<?php echo htmlspecialchars($row['course_id']); ?>">

     
		<label for="enrollment_id">Enrollment ID</label>
        <input type="number" id="enrollment_id" name="enrollment_id" required value="<?php echo htmlspecialchars($row['enrollment_id']); ?>">
		
		
		<label for="prerequisite_course_id">Prerequisite Course ID</label>
        <input type="number" id="prerequisite_course_id" name="prerequisite_course_id" required value="<?php echo htmlspecialchars($row['prerequisite_course_id']); ?>">
		

        <button type="submit" name="update">Update</button>
    </form>
</div>
<?php else: ?>
<p>Prerequisite data not found.</p>
<?php endif; ?>

</body>
</html>