<?php

$page_roles = array('advisor');
require_once 'db-info.php';
require_once 'checksession.php';



$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);


if (isset($_POST['delete'])) {
    $faculty_course_id = $_POST['faculty_course_id'];


    $query = "DELETE FROM faculty_course WHERE faculty_course_id='$faculty_course_id'";

  
    $result = $conn->query($query);
    if (!$result) die($conn->error);

   
    header("Location: course-assignment-list.php"); 
    exit;
}


$conn->close();
?>
