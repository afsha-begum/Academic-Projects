<?php
$page_roles = array('advisor');
require_once 'db-info.php';
require_once 'checksession.php';


$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$query = "SELECT * FROM enrollment";
$result = $conn->query($query);
if (!$result) die("Database access failed: " . $conn->error);

$rows = $result->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<p style="text-align: right; margin-top: 20px;">
        <a href="logout.php">Logout</a>
</p>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Enrollment List</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
<style>
    body {
        background-color: #f2f2f2;
        padding-top: 20px;
    }

    .view-program-container {
        background-color: #ffffff;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }

    .table {
        margin-top: 20px;
    }

    .action-buttons a {
        margin-right: 8px;
      
    }
	.add-button-container {
    margin-top: 20px;
}

    .action-buttons a.btn-primary {
        background-color: #007bff;
        border-color: #007bff;
    }

    .action-buttons a.btn-primary:hover {
        background-color: #0069d9;
        border-color: #0062cc;
    }

    .table-full-width {
        min-width: 100%;
    }

    td, th {
        padding: .5rem;
    }
</style>
</head>
<body>

<div class="container-fluid view-program-container">
    <div class="row align-items-center justify-content-between">
        <div class="col-auto">
            <a href="advisor-portal.php" class="btn btn-primary">
                &larr; Back to Advisor Portal
            </a>
        </div>

        <div class="col text-center">
            <h2>Enrollment List</h2>
        </div>

        <div class="col-auto">
            <a href="add-enrollment.php" class="btn btn-primary">
                Add New Enrollment
            </a>
        </div>
    </div>
    
    <div class="table-responsive">
        <table class="table table-bordered table-full-width">
            <thead>
                <tr>
                    <th>Enrollment ID</th>
                    <th>Enrollment Date</th>
                    <th>Enrollment Status</th>
					<th>Student ID</th>
                    <th>Course ID</th>
                    <th>Semester ID</th>
                </tr>
            </thead>
            <tbody>
                <?php
                for ($j = 0; $j < $rows; ++$j) {
                    $row = $result->fetch_array(MYSQLI_ASSOC);
                    echo "<tr>";
                    echo "<td>{$row['enrollment_id']}</td>";
                    echo "<td>{$row['enrollment_date']}</td>";
                    echo "<td>{$row['enrollment_status']}</td>";
					echo "<td>{$row['student_id']}</td>";
                    echo "<td>{$row['course_id']}</td>";
                    echo "<td>{$row['semester_id']}</td>";
                    echo "<td>
        <div class='d-flex justify-content-start'>
            <a href='update-enrollment.php?enrollment_id={$row['enrollment_id']}' class='btn btn-primary me-2'>Update</a>
            <form action='delete-enrollment.php' method='post'>
                                    <input type='hidden' name='delete' value='yes'>
                                    <input type='hidden' name='enrollment_id' value='{$row['enrollment_id']}'>
                                    <input type='submit' value='Delete' class='btn btn-danger me-2'>
                                </form>
        </div>
    </td>";
echo "</tr>";

                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
