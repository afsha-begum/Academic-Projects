<?php

$page_roles = array('advisor');
require_once 'db-info.php';
require_once 'checksession.php';


$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $program_id = $conn->real_escape_string($_POST['program_id']);
    $name = $conn->real_escape_string($_POST['name']);
    $type = $conn->real_escape_string($_POST['type']);
    $department = $conn->real_escape_string($_POST['department']);
	
    
    
    $query = "INSERT INTO program (name, type, department) VALUES ('$name', '$type', '$department')";
    
    $result = $conn->query($query);
    if (!$result) die("Database access failed: " . $conn->error);

    
    header("Location: program-list.php");
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<p style="text-align: right; margin-top: 20px;">
        <a href="logout.php">Logout</a>
    </p>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Program</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        padding: 20px;
    }
    .container {
        background-color: #ffffff;
        padding: 20px;
        max-width: 400px;
        margin: auto;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }
    h2 {
        text-align: center;
        color: #333;
    }
    label {
        display: block;
        margin-top: 10px;
    }
    input[type="text"],
    input[type="email"],
    input[type="number"],
    input[type="submit"],
    button {
        width: 90%;
        padding: 10px;
        margin-top: 5px;
        border: 2px solid #ccc;
        border-radius: 2px;
    }
    input[type="submit"],
    button {
        border: none;
        background-color: #0078d4;
        color: white;
        cursor: pointer;
        margin-top: 15px;
    }
    input[type="submit"]:hover,
    button:hover {
        background-color: #0056b3;
    }
</style>
</head>
<body>

<div class="container">
    <h2>Add Program</h2>
    <form method="post" action="add-program.php">
        
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required>
        
        <label for="type">Type</label>
        <input type="text" id="type" name="type" required>
        
		
		<label for="department">Department</label>
        <input type="text" id="department" name="department" required>
       
        
        <button type="submit">Add</button>
    </form>
   
</div>
</div>

</body>
</html>
