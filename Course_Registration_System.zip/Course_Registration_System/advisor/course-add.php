<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Course</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .add-course-button {
            display: inline-block;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            background-color: #007bff; /* Blue color */
            transition: background-color 0.3s ease;
        }

        .add-course-button:hover {
            background-color: #0056b3; /* Darker blue color on hover */
        }
    </style>
</head>

<body>
    <?php
    require_once 'db-info.php';
    require_once 'user.php';

    // Start or resume the session
    session_start();

    $conn = new mysqli($hn, $un, $pw, $db);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the form is submitted and the 'add' parameter is set to 'yes'
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add']) && $_POST['add'] === 'yes') {
        // Check if the user is set in the session
        if (isset($_SESSION['user'])) {
            // Get user information from the session
            $user = $_SESSION['user'];

            // Check if the User class has a getUsername() method
            if (method_exists($user, 'getUsername')) {
                $username = $user->getUsername();

                // Retrieve the course_id from the form submission
                $course_id = $conn->real_escape_string($_POST['course_id']);

                // Start a transaction
                $conn->begin_transaction();

                // Perform the insertion into the enrollment table
                $enrollment_query = "INSERT INTO enrollment (student_id, course_id) VALUES (
                    (SELECT s.student_id FROM student s
                    JOIN users u ON s.first_name = u.forename
                    WHERE u.username = '$username'),
                    '$course_id'
                )";
                $enrollment_result = $conn->query($enrollment_query);

                if ($enrollment_result) {
                    // Update the student table
                    $update_student_query = "UPDATE student SET course_id = '$course_id' WHERE student_id = (
                        SELECT s.student_id FROM student s
                        JOIN users u ON s.first_name = u.forename
                        WHERE u.username = '$username'
                    )";
                    $update_student_result = $conn->query($update_student_query);

                    if ($update_student_result) {
                        // Commit the transaction if successful
                        $conn->commit();

                        // Update the enrolled courses information in the session
                        $_SESSION['enrolled_courses'] = fetchEnrolledCourses($conn, $username);

                        // Success: Redirect back to the course view page
                        header("Location: course-view.php");
                        exit;
                    } else {
                        // Roll back the transaction and provide feedback to the user
                        $conn->rollback();
                        echo "Update student table failed: " . $update_student_query . "<br>" . $conn->error;
                    }
                } else {
                    // Roll back the transaction and provide feedback to the user
                    $conn->rollback();
                    echo "Enrollment failed: " . $enrollment_query . "<br>" . $conn->error;
                }
            } else {
                // Error: getUsername() method not found in User class
                echo "Error: getUsername() method not found in User class";
            }
        } else {
            // Error: User not logged in
            echo "User not logged in";
        }
    }

    // Fetch the list of courses
    $query = "SELECT * FROM course";
    $result = $conn->query($query);

    if (!$result) {
        die("Query failed: " . $conn->error);
    }

    // Start the table
    echo '<table>';
    echo '<tr><th>Course ID</th><th>Course Name</th><th>Description</th><th>Credit Hours</th><th>Department</th><th>Start Date</th><th>End Date</th><th>Course Schedule</th><th>Action</th></tr>';

    while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
        echo '<tr>';
        echo "<td>{$row['course_id']}</td>";
        echo "<td>{$row['course_name']}</td>";
        echo "<td>{$row['course_description']}</td>";
        echo "<td>{$row['credit_hours']}</td>";
        echo "<td>{$row['department']}</td>";
        echo "<td>{$row['course_start_date']}</td>";
        echo "<td>{$row['course_end_date']}</td>";
        echo "<td>{$row['course_schedule']}</td>";
        echo '<td>';
        echo "<form action='course-add.php' method='post'>";
        echo "<input type='hidden' name='add' value='yes'>";
        echo "<input type='hidden' name='course_id' value='{$row['course_id']}'>";
        echo "<input type='submit' class='add-course-button' value='ADD Course'>";
        echo '</form>';
        echo '</td>';
    }

    // End the table
    echo '</table>';

    // Close the result set and database connection
    $result->close();
    $conn->close();

    // Function to fetch enrolled courses
    function fetchEnrolledCourses($conn, $username)
    {
        $enrolled_courses_query = "SELECT c.course_id, c.course_name, c.course_description, c.credit_hours, c.course_start_date, c.course_end_date, c.course_schedule
                                FROM enrollment e
                                JOIN course c ON e.course_id = c.course_id
                                JOIN student s ON e.student_id = s.student_id
                                JOIN users u ON s.first_name = u.forename
                                WHERE u.username = '$username'";
        $enrolled_courses_result = $conn->query($enrolled_courses_query);

        $enrolled_courses = array();

        if ($enrolled_courses_result) {
            while ($row = $enrolled_courses_result->fetch_array(MYSQLI_ASSOC)) {
                $enrolled_courses[] = $row;
            }
        }

        return $enrolled_courses;
    }
    ?>
</body>

</html>
