<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Course</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .add-course-button {
            display: inline-block;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            background-color: #007bff; 
            transition: background-color 0.3s ease;
        }

        .add-course-button:hover {
            background-color: #0056b3; 
        }
    </style>
</head>

<body>
    <?php
   
    require_once 'db-info.php';
    require_once 'User.php';
    session_start();

    
    $conn = new mysqli($hn, $un, $pw, $db);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

   
    if (isset($_SESSION['user'])) {
        $user = $_SESSION['user'];
        $username = $user->getUsername();

       
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add']) && $_POST['add'] === 'yes') {
    $course_id = $conn->real_escape_string($_POST['course_id']);
    
    
    $check_enrollment_query = "SELECT * FROM enrollment WHERE student_id = (
        SELECT student_id FROM student WHERE first_name = (
            SELECT forename FROM users WHERE username = '$username'
        )
    ) AND course_id = '$course_id'";
    $check_enrollment_result = $conn->query($check_enrollment_query);

    if ($check_enrollment_result && $check_enrollment_result->num_rows === 0) {
        
        $enrollment_query = "INSERT INTO enrollment (student_id, course_id, enrollment_status, grade, semester_id) VALUES (
    (SELECT student_id FROM student WHERE first_name = (
        SELECT forename FROM users WHERE username = '$username'
    )),
    '$course_id',
    'Enrolled',
    'TBD',
    'semester_id'
)";
        $enrollment_result = $conn->query($enrollment_query);

        if ($enrollment_result) {
            echo "Course added successfully!";
            
          
            header("Location: course-view.php");
            exit;
        } else {
            echo "Enrollment failed: " . $enrollment_query . "<br>" . $conn->error;
        }
    } else {
        echo "You are already enrolled in this course.";
    }
}

      
        $query = "SELECT * FROM course";
        $result = $conn->query($query);

        if (!$result) {
            die("Query failed: " . $conn->error);
        }

        
        echo '<table>';
        echo '<tr><th>Course ID</th><th>Course Name</th><th>Description</th><th>Credit Hours</th><th>Department</th><th>Start Date</th><th>End Date</th><th>Course Schedule</th><th>Action</th></tr>';

        while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
            echo '<tr>';
            echo "<td>{$row['course_id']}</td>";
            echo "<td>{$row['course_name']}</td>";
            echo "<td>{$row['course_description']}</td>";
            echo "<td>{$row['credit_hours']}</td>";
            echo "<td>{$row['department']}</td>";
            echo "<td>{$row['course_start_date']}</td>";
            echo "<td>{$row['course_end_date']}</td>";
            echo "<td>{$row['course_schedule']}</td>";
            echo '<td>';
            echo "<form action='course-add.php' method='post'>";
            echo "<input type='hidden' name='add' value='yes'>";
            echo "<input type='hidden' name='course_id' value='{$row['course_id']}'>";
            echo "<input type='submit' class='add-course-button' value='ADD Course'>";
            echo '</form>';
            echo '</td>';
        }

        
        echo '</table>';

        
        $result->close();
        $conn->close();
    } else {
        echo "User not logged in";
    }
    ?>
</body>

</html>
