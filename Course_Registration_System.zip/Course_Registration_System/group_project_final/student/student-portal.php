<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Portal</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f2f2f2;
    }
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 20px;
        background-color: #fff;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .logo {
        height: 150px;
    }
    .student{
        font-size: 1.5em;
        color: #333;
    }
    .navigation {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        padding: 20px;
        max-width: 1000px;
        margin: 40px auto;
        background-color: #fff;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }
    .nav-link {
        padding: 10px 15px;
        text-align: center;
        background-color: #007bff;
        color: white;
        text-decoration: none;
        border: none;
        border-radius: 4px;
        transition: background-color 0.3s ease;
    }
    .nav-link:hover {
        background-color: #0056b3;
    }
    .footer {
        text-align: center;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        position: fixed;
        bottom: 0;
        width: 100%;
    }
		.logout-button {
            padding: 10px 15px;
            text-align: center;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .logout-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="header">
    <div class="student">Student</div>
	<img src="logo.jpg" alt="INTI Logo" class="logo">
    <a href="logout.php" class="logout-button">Logout</a>
</div>

<div class="navigation">
	<a href="view-details.php" class="nav-link">Student Profile</a>
    <a href="course-view.php" class="nav-link">View Courses</a>
	<a href="academic-records.php" class="nav-link">Academic Records</a>
	<a href="other.php" class="nav-link">Other</a>
</div>

<div class="footer">
    <p>&copy; 2023 INTI College. All rights reserved.</p>
</div>

</body>
</html>
<?php
$page_roles = array('student');

require_once 'db-info.php';
require_once 'User.php';
require_once 'checksession.php';

$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);

if (isset($_SESSION['user']) && $_SESSION['user'] instanceof User) {
    $user = $_SESSION['user'];
    $username = $user->getUsername();
}
?>