<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Information</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            text-align: center; /* Center the text within the container */
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            padding: 20px;
        }

        .student-info {
            margin-bottom: 20px;
        }

        .actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px; /* Added margin to separate from student-info */
        }

        .update-link,
        .logout-button,
        .back-button {
            padding: 10px 15px;
            text-align: center;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            cursor: pointer;
            text-decoration: none;
        }

        .update-link,
        .logout-button,
        .back-button {
            color: white;
        }

        .update-link,
        .logout-button {
            background-color: #007bff;
        }

        .update-link:hover,
        .logout-button:hover {
            background-color: #0056b3;
        }

        .back-button {
            background-color: #007bff;
            color: #fff;
        }

        .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <?php
	
	$page_roles=array('student');
    require_once 'db-info.php';
    require_once 'User.php';
	require_once 'checksession.php';


    $conn = new mysqli($hn, $un, $pw, $db);
    if ($conn->connect_error) die($conn->connect_error);

    if (isset($_SESSION['user']) && $_SESSION['user'] instanceof User) {
        $user = $_SESSION['user'];
        $username = $user->getUsername();

        $query = "SELECT s.* FROM student s 
                  JOIN users u ON s.first_name = u.forename
                  WHERE u.username = '$username' LIMIT 1";

        $result = $conn->query($query);

        if (!$result) die($conn->error);

        $row = $result->fetch_array(MYSQLI_ASSOC);
        ?>
        <div class="student-info">
            <h2>Student Information</h2>
            <p><strong>Student ID:</strong> <?php echo $row['student_id']; ?></p>
            <p><strong>First Name:</strong> <?php echo $row['first_name']; ?></p>
            <p><strong>Last Name:</strong> <?php echo $row['last_name']; ?></p>
            <p><strong>Year:</strong> <?php echo $row['year']; ?></p>
            <p><strong>GPA:</strong> <?php echo $row['gpa']; ?></p>
            <p><strong>Major:</strong> <?php echo $row['major']; ?></p>
            <p><strong>Phone:</strong> <?php echo $row['phone_number']; ?></p>
            <p><strong>Address:</strong> <?php echo $row['address']; ?></p>
            <p><strong>Email:</strong> <?php echo $row['email']; ?></p>
        </div>

        <div class="actions">
			<a href="student-portal.php" class="back-button">Back to Portal</a>
            <a href="student-update.php?student_id=<?php echo $row['student_id']; ?>" class="update-link">Update</a>
            <form action="logout.php" method="post">
                <input type="submit" value="Logout" class="logout-button">
            </form>
            
        </div>
        <?php
    } else {
        echo "Invalid access";
    }

    $conn->close();
    ?>
</div>

</body>
</html>
