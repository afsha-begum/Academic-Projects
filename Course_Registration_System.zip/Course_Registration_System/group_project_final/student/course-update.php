<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Update</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px; 
            margin: auto; 
            text-align: center;
        }

        input[type="text"] {
            width: calc(100% - 16px); 
            padding: 8px;
            margin-bottom: 15px;
            box-sizing: border-box;
            text-align: center; 
        }

        label {
            display: block;
            text-align: center; 
            margin-bottom: 5px;
            font-weight: bold; 
        }

        .info-container {
            text-align: center;
            margin-bottom: 15px;
        }

        select {
            width: calc(100% - 16px);
            padding: 8px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #007bff; 
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease; 
            width: 100%; /* Make the button full-width 
        }

        input[type="submit"]:hover {
            background-color: #0056b3; 
        }

        h2 {
            text-align: center;
        }

        .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<?php

$page_roles=array('student');

require_once 'db-info.php';
require_once 'checksession.php';

$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);

if (isset($_GET['course_id'])) {
    $course_id = $_GET['course_id'];

    $query = "SELECT * FROM course WHERE course_id = $course_id";
    $result = $conn->query($query);

    if (!$result) die($conn->error);

    $rows = $result->num_rows;

    for ($j = 0; $j < $rows; $j++) {
        $row = $result->fetch_array(MYSQLI_ASSOC);

        $course_schedule = $row['course_schedule'];
        $A = $B = $C = $D = '';
        if ($course_schedule == 'M-W 6:00PM-10:00PM') $A = 'selected';
        if ($course_schedule == 'T,Th 6:00PM-10:00PM') $B = 'selected';
        if ($course_schedule == 'M-F 9:00AM-10:00AM') $C = 'selected';
        if ($course_schedule == 'Online') $D = 'selected';

        echo <<<_END
        <form action='course-update.php' method='post'>
            <h2>Course Update</h2>
            <div class="info-container">
                <label>Course ID:</label>
                <p>{$row['course_id']}</p>
                <label>Course Name:</label>
                <p>{$row['course_name']}</p>
                <label>Course Description:</label>
                <p>{$row['course_description']}</p>
                <label>Start Date:</label>
                <p>{$row['course_start_date']}</p>
                <label>End Date:</label>
                <p>{$row['course_end_date']}</p>
            </div>
            <label for="course_schedule">Select Schedule:</label>
            <select name='course_schedule' id='course_schedule'>
                <option value='M-W 6:00PM-10:00PM' $A>M-W 6:00PM-10:00PM</option>
                <option value='T,Th 6:00PM-10:00PM' $B>T,Th 6:00PM-10:00PM</option>
                <option value='M-F 9:00AM-10:00AM' $C>M-F 9:00AM-10:00AM</option>
                <option value='Online' $D>Online</option>
            </select>
            <input type='hidden' name='update' value='yes'>
            <input type='hidden' name='course_id' value='{$row['course_id']}'>
            <input type='submit' value='UPDATE RECORD'>
        </form>
_END;
    }
}

if (isset($_POST['update'])) {
    $course_id = $_POST['course_id'];
    $course_schedule = $_POST['course_schedule'];

    $query = "UPDATE course SET course_schedule='$course_schedule' WHERE course_id = $course_id";

    $result = $conn->query($query);
    if (!$result) die($conn->error);

    header("Location: course-view.php");
}

$conn->close();
?>
</body>
</html>
