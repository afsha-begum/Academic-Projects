<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Update</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px; 
            margin: auto;
			text-align: center;
        }

        input[type="text"] {
            width: calc(100% - 16px); 
            padding: 8px;
            margin-bottom: 15px;
            box-sizing: border-box;
            text-align: center; 
        }

        label {
            display: block;
            text-align: center;
            margin-bottom: 5px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
            width: 100%; 
        }

        input[type="submit"]:hover {
            background-color: #0056b3; 
        }

        h2 {
            text-align: center;
        }

        .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<?php
$page_roles=array('student');

require_once 'db-info.php';
require_once 'checksession.php';


$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);

if (isset($_GET['student_id'])) {
    $studentID = $_GET['student_id'];

    $query = "SELECT * FROM student WHERE student_id=$studentID";
    $result = $conn->query($query);

    if (!$result) die($conn->error);

    $row = $result->fetch_array(MYSQLI_ASSOC);

    if ($row) {
        echo <<<_END
        <form action='student-update.php' method='post'>
            <h2>Student Update</h2>
            <label>Student ID:</label>
            <p>{$row['student_id']}</p>
            <label>First Name:</label>
            <p>{$row['first_name']}</p>
            <label>Last Name:</label>
            <p>{$row['last_name']}</p>
            <label>Phone Number:</label>
            <input type='text' name='phone_number' value='{$row['phone_number']}'>
            <label>Address:</label>
            <input type='text' name='address' value='{$row['address']}'>
            <label>Email:</label>
            <input type='text' name='email' value='{$row['email']}'>
            <input type='hidden' name='update' value='yes'>
            <input type='hidden' name='student_id' value='{$row['student_id']}'>
            <input type='submit' value='UPDATE'>
        </form>
_END;
    } else {
        echo "<p class='error'>No student information found.</p>";
    }
}

if (isset($_POST['update'])) {
    $student_id = $_POST['student_id'];
    $phone_number = $conn->real_escape_string($_POST['phone_number']);
    $address = $conn->real_escape_string($_POST['address']);
    $email = $conn->real_escape_string($_POST['email']);

    $query = "UPDATE student SET phone_number='$phone_number', address='$address', email='$email' WHERE student_id = $student_id";

    $result = $conn->query($query);
    if (!$result) die($conn->error);

    header("Location: view-details.php");
}

$conn->close();
?>

</body>
</html>
