<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Information</title>
    <style>
        body {
            background-color: #f2f2f2;
            padding-top: 20px;
        }

        .view-student-container {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .table {
            margin-top: 20px;
        }

        .actions {
            position: absolute;
            top: 10px;
            right: 10px;
            display: flex;
            gap: 10px; 
        }

        .table-full-width {
            min-width: 100%;
        }

        td, th {
            padding: .5rem;
        }

        .update-button {
            display: inline-block;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            background-color: #007bff;
            transition: background-color 0.3s ease;
        }

        .update-button:hover {
            background-color: #0056b3;
        }

        .add-button {
            display: inline-block;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            background-color: #FFDB58;
            transition: background-color 0.3s ease;
        }

        .add-button:hover {
            background-color: #0056b3;
        }

        .delete-button {
            display: inline-block;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            background-color: #FF3333;
            transition: background-color 0.3s ease;
        }

        .delete-button:hover {
            background-color: #0056b3;
        }

        .logout-button {
            display: inline-block;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            background-color: #007bff; 
            transition: background-color 0.3s ease;
        }

        .logout-button:hover {
            background-color: #0056b3;
        }

        .back-to-portal-button {
            display: inline-block;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            background-color: #007bff;
            transition: background-color 0.3s ease;
        }

        .back-to-portal-button:hover {
            background-color: #218838;
        }
		.add-button {
            display: inline-block;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            background-color: #007bff; 
            transition: background-color 0.3s ease;
        }

        .add-button:hover {
            background-color: #0056b3; 
        }
    </style>
</head>
<body>

<?php

$page_roles=array('student');

require_once 'db-info.php';
require_once 'User.php';
require_once 'checksession.php';

$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);

if (isset($_SESSION['user']) && $_SESSION['user'] instanceof User) {
    $user = $_SESSION['user'];
    $username = $user->getUsername();

    $query = "SELECT s.student_id, s.first_name, s.last_name, c.course_id, c.course_name, c.course_description, c.credit_hours, c.course_start_date, c.course_end_date, c.course_schedule, e.enrollment_status, e.grade
              FROM student s 
              JOIN enrollment e ON s.student_id = e.student_id
              JOIN prerequisite p ON e.course_id = p.course_id
              JOIN course c ON p.course_id = c.course_id
              JOIN users u ON s.first_name = u.forename
              WHERE u.username = '$username' AND e.grade <> 'TBD'";

    $result = $conn->query($query);

    if (!$result) {
        die($conn->error);
    }

    if ($result->num_rows > 0) {
        echo '<div class="view-course-container">';
        // Display student information outside of the table
        $row = $result->fetch_assoc();
        echo '<div class="student-info">';
        echo '<h2>Student Information</h2>';
        echo '<p><strong>Student ID:</strong> ' . $row['student_id'] . '</p>';
        echo '<p><strong>First Name:</strong> ' . $row['first_name'] . '</p>';
        echo '<p><strong>Last Name:</strong> ' . $row['last_name'] . '</p>';
        echo '</div>';

        // Display the enrolled courses in a table
        echo '<table border="1" class="table-full-width">';
        echo '<tr>';
        echo '<th>Course ID</th>';
        echo '<th>Course Name</th>';
        echo '<th>Description</th>';
        echo '<th>Credit Hours</th>';
        echo '<th>Start Date</th>';
        echo '<th>End Date</th>';
        echo '<th>Enrollment Status</th>';
        echo '<th>Grade</th>';
        echo '</tr>';

        do {
            echo '<tr>';
            echo '<td>' . $row['course_id'] . '</td>';
            echo '<td>' . $row['course_name'] . '</td>';
            echo '<td>' . $row['course_description'] . '</td>';
            echo '<td>' . $row['credit_hours'] . '</td>';
            echo '<td>' . $row['course_start_date'] . '</td>';
            echo '<td>' . $row['course_end_date'] . '</td>';
            echo '<td>' . $row['enrollment_status'] . '</td>';
            echo '<td>' . $row['grade'] . '</td>';
            echo '</tr>';
        } while ($row = $result->fetch_assoc());

        echo '</table>';
    } else {
        echo "No courses found for the specified user.";
    }
} else {
    echo "Invalid access";
}

$conn->close();
?>

<div class="actions">
    <form action="student-portal.php" method="post">
        <input type="submit" value="Back to Portal" class="back-to-portal-button">
    </form>

    <form action="logout.php" method="post">
        <input type="submit" value="Logout" class="logout-button">
    </form>
</div>

</body>
</html>

