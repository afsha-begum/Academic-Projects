<?php

$page_roles = array('student');

require_once 'db-info.php';
require_once 'checksession.php';

$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);

if (isset($_POST['delete'])) {
    $course_id = $_POST['course_id'];
    $student_id = $_POST['student_id'];

   
    $query = "DELETE FROM enrollment WHERE student_id='$student_id' AND course_id='$course_id'";
    $result = $conn->query($query);

    if (!$result) {
        die($conn->error);
    }

  
    header("Location: course-view.php");
}

$conn->close();
?>
