SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int AUTO_INCREMENT NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `admin` (first_name, last_name, email) VALUES
('Bill', 'Smith', 'bill.smith@email.com'),
('Emily', 'Johnson', 'emily.johnson@email.com'),
('Michael', 'Williams', 'michael.williams@email.com'),
('David', 'Brown', 'david.brown@email.com'),
('Sarah', 'Jones', 'sarah.jones@email.com'),
('Daniel', 'Miller', 'daniel.miller@email.com'),
('Laura', 'Wilson', 'laura.wilson@email.com'),
('James', 'Taylor', 'james.taylor@email.com'),
('Anna', 'Anderson', 'anna.anderson@email.com'),
('Robert', 'Thomas', 'robert.thomas@email.com'),
('Jessica', 'Harris', 'jessica.harris@email.com'),
('Mark', 'Martin', 'mark.martin@email.com'),
('Emma', 'Thompson', 'emma.thompson@email.com'),
('William', 'Garcia', 'william.garcia@email.com'),
('Olivia', 'Martinez', 'olivia.martinez@email.com'),
('Richard', 'Robinson', 'richard.robinson@email.com'),
('Sophia', 'Clark', 'sophia.clark@email.com'),
('Joseph', 'Rodriguez', 'joseph.rodriguez@email.com'),
('Lily', 'Lewis', 'lily.lewis@email.com'),
('Daniel', 'Smith', 'daniel.smith@email.com');


DROP TABLE IF EXISTS `advisor`;
CREATE TABLE IF NOT EXISTS `advisor` (
  `advisor_id` int AUTO_INCREMENT NOT NULL, 
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `admin_id` int DEFAULT NULL,
  `is_active` BOOLEAN NOT NULL DEFAULT 1,
  PRIMARY KEY (`advisor_id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `advisor` (`first_name`, `last_name`, `email`, `admin_id`, `is_active`) VALUES
('Paulina', 'Jones', 'paulina.jones@email.com', 1, 1),
('Emily', 'Johnson', 'emily.johnson@email.com', 2, 1),
('Michael', 'Brown', 'michael.brown@email.com', 3, 1),
('Sarah', 'Davis', 'sarah.davis@email.com', 4, 1),
('William', 'Miller', 'william.miller@email.com', 5, 1),
('Jessica', 'Wilson', 'jessica.wilson@email.com', 6, 1),
('David', 'Moore', 'david.moore@email.com', 7, 1),
('Jennifer', 'Taylor', 'jennifer.taylor@email.com', 8, 1),
('Richard', 'Anderson', 'richard.anderson@email.com', 9, 1),
('Lisa', 'Thomas', 'lisa.thomas@email.com', 10, 1),
('Charles', 'Jackson', 'charles.jackson@email.com', 11, 1),
('Mary', 'White', 'mary.white@email.com', 12, 1),
('Daniel', 'Harris', 'daniel.harris@email.com', 13, 1),
('Susan', 'Martin', 'susan.martin@email.com', 14, 1),
('Paul', 'Thompson', 'paul.thompson@email.com', 15, 1),
('Laura', 'Garcia', 'laura.garcia@email.com', 16, 1),
('James', 'Martinez', 'james.martinez@email.com', 17, 1),
('Karen', 'Robinson', 'karen.robinson@email.com', 18, 1),
('Robert', 'Clark', 'robert.clark@email.com', 19, 1),
('Patricia', 'Rodriguez', 'patricia.rodriguez@email.com', 20, 1);


DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `student_id` int AUTO_INCREMENT NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `address` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gpa` varchar (20) NOT NULL,
  `major` varchar(100) NOT NULL,
  `year` varchar(20) NOT NULL,
  `enrollment_id` int NOT NULL,
  `admin_id` int DEFAULT NULL,
  `advisor_id` int DEFAULT NULL,
  `program_id` int NOT NULL,
  `is_active` BOOLEAN NOT NULL DEFAULT 1,
  PRIMARY KEY (`student_id`),
  KEY `enrollment_id` (`enrollment_id`),
  KEY `admin_id` (`admin_id`),
  KEY `advisor_id` (`advisor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `student` (`first_name`, `last_name`, `phone_number`, `address`, `email`, `gpa`, `major`, `year`, `enrollment_id`, `admin_id`, `advisor_id`, `program_id`, `is_active`) VALUES
('John', 'Doe', '123-456-7890', '123 Main St, City', 'john.doe@email.com', '3.5', 'Computer Science', 'Freshman', 1, 1, 1, 1, 1),
('Emily', 'Smith', '234-567-8901', '456 Oak St, Town', 'emily.smith@email.com', '3.2', 'Mathematics', 'Sophomore', 2, 2, 2, 2, 1),
('Michael', 'Brown', '345-678-9012', '789 Pine St, Village', 'michael.brown@email.com', '3.4', 'Chemistry', 'Junior', 3, 3, 3, 3, 1),
('Sarah', 'Johnson', '456-789-0123', '101 Elm St, County', 'sarah.johnson@email.com', '4.0', 'Physics', 'Senior', 4, 4, 4, 4, 1),
('William', 'Davis', '567-890-1234', '202 Maple St, District', 'william.davis@email.com', '3.7', 'English', 'Graduate', 5, 5, 5, 5, 1),
('Jessica', 'Miller', '678-901-2345', '303 Oak St, Town', 'jessica.miller@email.com', '3.8', 'Business', 'Freshman', 6, 6, 6, 6, 1),
('David', 'Wilson', '789-012-3456', '404 Pine St, Village', 'david.wilson@email.com', '2.9', 'Biology', 'Sophomore', 7, 7, 7, 7, 1),
('Jennifer', 'Moore', '890-123-4567', '505 Elm St, County', 'jennifer.moore@email.com', '3.3', 'Engineering', 'Junior', 8, 8, 8, 8, 1),
('Richard', 'Taylor', '901-234-5678', '606 Oak St, Town', 'richard.taylor@email.com', '3.9', 'Psychology', 'Senior', 9, 9, 9, 9, 1),
('Lisa', 'Anderson', '012-345-6789', '707 Pine St, Village', 'lisa.anderson@email.com', '4.0', 'Political Science', 'Graduate', 10, 10, 10, 10, 1),
('Charles', 'Thomas', '123-456-7890', '808 Elm St, County', 'charles.thomas@email.com', '3.3', 'Art', 'Freshman', 11, 11, 11, 11, 1),
('Mary', 'Jackson', '234-567-8901', '909 Oak St, Town', 'mary.jackson@email.com', '3.5', 'Music', 'Sophomore', 12, 12, 12, 12, 1),
('Daniel', 'White', '345-678-9012', '1010 Pine St, Village', 'daniel.white@email.com', '3.8', 'History', 'Junior', 13, 13, 13, 13, 1),
('Susan', 'Harris', '456-789-0123', '1111 Elm St, County', 'susan.harris@email.com', '3.0', 'Sociology', 'Senior', 14, 14, 14, 14, 1),
('Paul', 'Martin', '567-890-1234', '1212 Oak St, Town', 'paul.martin@email.com', '3.0', 'Philosophy', 'Graduate', 15, 15, 15, 15, 1),
('Laura', 'Garcia', '678-901-2345', '1313 Pine St, Village', 'laura.garcia@email.com', '3.4', 'Computer Science', 'Freshman', 16, 16, 16, 16, 1),
('James', 'Martinez', '789-012-3456', '1414 Elm St, County', 'james.martinez@email.com', '4.0', 'Mathematics', 'Sophomore', 17, 17, 17, 17, 1),
('Karen', 'Robinson', '890-123-4567', '1515 Oak St, Town', 'karen.robinson@email.com', '3.9', 'Chemistry', 'Junior', 18, 18, 18, 18, 1),
('Robert', 'Clark', '901-234-5678', '1616 Pine St, Village', 'robert.clark@email.com', '3.1', 'Physics', 'Senior', 19, 19, 19, 19, 1),
('Patricia', 'Lewis', '012-345-6789', '1717 Elm St, County', 'patricia.lewis@email.com', '3.2', 'English', 'Graduate', 20, 20, 20, 20, 1);




DROP TABLE IF EXISTS `faculty`;
CREATE TABLE IF NOT EXISTS `faculty` (
  `faculty_id` int AUTO_INCREMENT NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `course_id` int NOT NULL,
  `admin_id` int DEFAULT NULL,
  `is_active` BOOLEAN NOT NULL DEFAULT 1,
  PRIMARY KEY (`faculty_id`),
  KEY `course_id` (`course_id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `faculty` (`first_name`, `last_name`, `department`, `course_id`, `admin_id`, `is_active`) VALUES
('James', 'Miller', 'Mathematics', 1, 1, 1),
('Linda', 'Brown', 'Physics', 2, 2, 1),
('Michael', 'Davis', 'Chemistry', 3, 3, 1),
('Sarah', 'Wilson', 'Biology', 4, 4, 1),
('Robert', 'Moore', 'History', 5, 5, 1),
('Jessica', 'Taylor', 'Literature', 6, 6, 1),
('David', 'Anderson', 'Computer Science', 7, 7, 1),
('Jennifer', 'Jackson', 'Economics', 8, 8, 1),
('Richard', 'White', 'Philosophy', 9, 9, 1),
('Elizabeth', 'Harris', 'Political Science', 10, 10, 1),
('Joseph', 'Martin', 'Engineering', 11, 11, 1),
('Susan', 'Thompson', 'Art', 12, 12, 1),
('Thomas', 'Garcia', 'Music', 13, 13, 1),
('Karen', 'Martinez', 'Business', 14, 14, 1),
('Brian', 'Robinson', 'Law', 15, 15, 1),
('Nancy', 'Clark', 'Psychology', 16, 16, 1),
('Mark', 'Rodriguez', 'Sociology', 17, 17, 1),
('Betty', 'Lewis', 'Anthropology', 18, 18, 1),
('Paul', 'Lee', 'Astronomy', 19, 19, 1),
('Donna', 'Walker', 'Environmental Science', 20, 20, 1);



DROP TABLE IF EXISTS `faculty_course`;
CREATE TABLE IF NOT EXISTS `faculty_course` (
  `faculty_course_id` int AUTO_INCREMENT NOT NULL,
  `faculty_id` int NOT NULL,
  `course_id` int NOT NULL,
  PRIMARY KEY (`faculty_course_id`),
  KEY `faculty_id` (`faculty_id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `faculty_course` (`faculty_id`, `course_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 11),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16),
(17, 17),
(18, 18),
(19, 19),
(20, 20);



DROP TABLE IF EXISTS `prerequisite`;
CREATE TABLE IF NOT EXISTS `prerequisite` (
  `prerequisite_id` int AUTO_INCREMENT NOT NULL,
  `course_id` int NOT NULL,
  `enrollment_id` int NOT NULL,
  `prerequisite_course_id` int NOT NULL,
  `advisor_id` int DEFAULT NULL,
  PRIMARY KEY (`prerequisite_id`),
  KEY `course_id` (`course_id`),
  KEY `enrollment_id` (`enrollment_id`),
  KEY `prerequisite_course_id` (`prerequisite_course_id`),
  KEY `advisor_id` (`advisor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `prerequisite` (`course_id`, `enrollment_id`, `prerequisite_course_id`, `advisor_id`) VALUES
(1, 1, 2, 1),
(2, 2, 3, 2),
(3, 3, 4, 3),
(4, 4, 5, 4),
(5, 5, 6, 5),
(6, 6, 7, 6),
(7, 7, 8, 7),
(8, 8, 9, 8),
(9, 9, 10, 9),
(10, 10, 11, 10),
(11, 11, 12, 12),
(12, 12, 13, 11),
(13, 13, 14, 13),
(14, 14, 15, 14),
(15, 15, 16, 15),
(16, 16, 17, 16),
(17, 17, 18, 17),
(18, 18, 19, 18),
(19, 19, 20, 19),
(20, 20, 1, 20);


DROP TABLE IF EXISTS `course`;
CREATE TABLE IF NOT EXISTS `course` (
  `course_id` int AUTO_INCREMENT NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `course_description` varchar(200) NOT NULL,
  `credit_hours` int NOT NULL,
  `department` varchar(100) NOT NULL,
  `semester_id` int NOT NULL,
  `faculty_id` int NOT NULL,
  `course_start_date` date NOT NULL,
  `course_end_date` date NOT NULL,
  `course_schedule` varchar(100) NOT NULL,
  `is_active` BOOLEAN NOT NULL DEFAULT 1,
  PRIMARY KEY (`course_id`),
  KEY `semester_id` (`semester_id`),
  KEY `faculty_id` (`faculty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `course` (`course_name`, `course_description`, `credit_hours`, `department`, `course_start_date`, `course_end_date`, `semester_id`, `faculty_id`, `course_schedule`, `is_active`) VALUES
('Introduction to Computer Science', 'Fundamentals of programming and computer science concepts.', 4, 'Computer Science', '1995-09-01', '2023-12-15', 1, 1, 'M,W 6:00PM-10:00PM', 1),
('Calculus I', 'Introduction to differential and integral calculus.', 4, 'Mathematics', '1996-01-15', '2023-05-10', 2, 2, 'T, Th 6:00PM-10:00PM', 1),
('General Chemistry', 'Basic principles of chemistry including lab work.', 4, 'Chemistry', '1997-03-20', '2023-08-30', 3, 3, 'M-F 9:00AM-10:00AM', 1),
('Introduction to Psychology', 'Study of human behavior and mental processes.', 3, 'Psychology', '1998-05-25', '2023-12-20', 4, 4, 'Online', 1),
('World History', 'Overview of key events and movements in world history.', 3, 'History', '2023-07-30', '2023-11-30', 5, 5, 'T, Th 6:00PM-10:00PM', 1),
('Microeconomics', 'Fundamentals of microeconomic theory.', 3, 'Economics', '2000-10-03', '2023-12-10', 6, 6, 'M,W 6:00PM-10:00PM', 1),
('Organic Chemistry', 'Study of the structure, properties, and reactions of organic compounds.', 4, 'Chemistry', '2001-12-07', '2024-01-15', 7, 7, 'M,W 6:00PM-10:00PM', 1),
('American Literature', 'Survey of American literary history and major works.', 3, 'English', '2003-02-10', '2023-11-25', 8, 8, 'T, Th 6:00PM-10:00PM', 1),
('Physics I', 'Principles of physics with emphasis on mechanics and heat.', 4, 'Physics', '2021-04-15', '2023-12-22', 9, 9, 'M-F 9:00AM-10:00AM', 1),
('Introduction to Sociology', 'Exploration of social institutions and societal interactions.', 3, 'Sociology', '2005-06-20', '2023-11-20', 10, 10, 'Online', 1),
('Statistics', 'Introduction to statistical methods and applications.', 3, 'Mathematics', '2023-08-25', '2024-01-05', 11, 11, 'M,W 6:00PM-10:00PM', 1),
('Environmental Science', 'Study of environmental issues and ecological relationships.', 3, 'Biology', '2007-10-30', '2023-12-01', 12, 12, 'T, Th 6:00PM-10:00PM', 1),
('Graphic Design', 'Fundamentals of visual communication and design principles.', 3, 'Art', '2022-01-03', '2023-11-15', 13, 13, 'Online', 1),
('Computer Networks', 'Understanding of network design, protocols, and security.', 4, 'Computer Science', '2009-03-08', '2024-01-20', 14, 14, 'M,W 6:00PM-10:00PM', 1),
('Philosophy of Science', 'Examination of philosophical aspects of scientific inquiry.', 3, 'Philosophy', '2021-05-13', '2023-12-31', 15, 15, 'T, Th 6:00PM-10:00PM', 1),
('Business Management', 'Principles of management and organization in business.', 3, 'Business', '2011-07-18', '2023-11-18', 16, 16, 'M,W 6:00PM-10:00PM', 1),
('Human Anatomy', 'Comprehensive study of human body structure.', 4, 'Biology', '2012-09-22', '2023-12-15', 17, 17, 'Online', 1),
('Linear Algebra', 'Concepts of vector spaces and linear transformations.', 3, 'Mathematics', '2015-11-27', '2023-11-30', 18, 18, 'M-F 9:00AM-10:00AM', 1),
('Creative Writing', 'Workshop on writing fiction, poetry, and creative non-fiction.', 3, 'English', '2015-02-01', '2023-12-05', 19, 19, 'T, Th 6:00PM-10:00PM', 1),
('Marketing Fundamentals', 'Introduction to marketing concepts and strategies.', 3, 'Business', '2020-04-06', '2023-11-30', 20, 20, 'M,W 6:00PM-10:00PM', 1);





DROP TABLE IF EXISTS `semester`;
CREATE TABLE IF NOT EXISTS `semester` (
  `semester_id` int AUTO_INCREMENT NOT NULL,
  `status` varchar(100) NOT NULL,
  `year` varchar(20) NOT NULL,
  `program_id` int NOT NULL,
  `is_active` BOOLEAN NOT NULL DEFAULT 1,
  PRIMARY KEY (`semester_id`),
  KEY `program_id` (`program_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `semester` (`status`, `year`, `program_id`, `is_active`) VALUES
('Active', '1995-1996', 1, 1),
('Active', '1996-1997', 2, 1),
('Inactive', '1997-1998', 3, 0),
('Active', '1998-1999', 4, 1),
('Active', '1999-2000', 5, 1),
('Inactive', '2000-2001', 6, 0),
('Active', '2001-2002', 7, 1),
('Active', '2003-2004', 8, 1),
('Inactive', '2005-2006', 9, 0),
('Active', '2007-2008', 10, 1),
('Active', '2009-2010', 11, 1),
('Inactive', '2011-2012', 12, 0),
('Active', '2013-2014', 13, 1),
('Active', '2015-2016', 14, 1),
('Inactive', '2017-2018', 15, 0),
('Active', '2019-2020', 16, 1),
('Active', '2021-2022', 17, 1),
('Inactive', '2022-2023', 18, 0),
('Active', '2023-2024', 19, 1),
('Active', '2024-2025', 20, 1);


DROP TABLE IF EXISTS `program`;
CREATE TABLE IF NOT EXISTS `program` (
  `program_id` int AUTO_INCREMENT NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `advisor_id` int DEFAULT NULL,
  PRIMARY KEY (`program_id`),
  KEY `advisor_id` (`advisor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `program` (`name`, `type`, `department`, `advisor_id`) VALUES
('Computer Science Major', 'Undergraduate', 'Computer Science', 1),
('Mathematics Major', 'Undergraduate', 'Mathematics', 2),
('Chemistry Major', 'Undergraduate', 'Chemistry', 3),
('Physics Major', 'Undergraduate', 'Physics', 4),
('English Literature Major', 'Undergraduate', 'English', 5),
('Business Administration Major', 'Undergraduate', 'Business', 6),
('Biological Sciences Major', 'Undergraduate', 'Biology', 7),
('Engineering Major', 'Undergraduate', 'Engineering', 8),
('Psychology Major', 'Undergraduate', 'Psychology', 9),
('Political Science Major', 'Undergraduate', 'Political Science', 10),
('Art and Design Major', 'Undergraduate', 'Art', 11),
('Music Major', 'Undergraduate', 'Music', 12),
('History Major', 'Undergraduate', 'History', 13),
('Sociology Major', 'Undergraduate', 'Sociology', 14),
('Philosophy Major', 'Undergraduate', 'Philosophy', 15),
('Computer Science Minor', 'Undergraduate', 'Computer Science', 16),
('Mathematics Minor', 'Undergraduate', 'Mathematics', 17),
('Chemistry Minor', 'Undergraduate', 'Chemistry', 18),
('Physics Minor', 'Undergraduate', 'Physics', 19),
('English Literature Minor', 'Undergraduate', 'English', 20);

DROP TABLE IF EXISTS `enrollment`;
CREATE TABLE IF NOT EXISTS `enrollment` (
  `enrollment_id` int AUTO_INCREMENT NOT NULL,
  `enrollment_date` date NOT NULL,
  `enrollment_status` varchar(100) NOT NULL,
  `admin_id` int DEFAULT NULL,
  `student_id` int DEFAULT NULL,
  `course_id` int DEFAULT NULL,
  `semester_id` int DEFAULT NULL,
  `grade` varchar(100),
  PRIMARY KEY (`enrollment_id`),
  UNIQUE KEY `unique_enrollment` (`student_id`, `course_id`), -- Add this line
  FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`),
  FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`),
  FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  KEY `semester_id` (`semester_id`) 
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `enrollment` (`enrollment_date`, `enrollment_status`, `admin_id`, `student_id`, `course_id`, `semester_id`, `grade`) VALUES
('2023-01-15', 'Enrolled', 1, 1, 1, 1, 'A'),
('2023-01-16', 'Enrolled', 2, 2, 2, 2, 'B'),
('2023-01-17', 'Enrolled', 3, 3, 3, 3, 'TBD'),
('2023-01-18', 'Enrolled', 4, 4, 4, 1, 'B+'),
('2023-01-19', 'Enrolled', 5, 5, 5, 5, 'A-'),
('2023-01-20', 'Enrolled', 6, 6, 6, 6, 'TBD'),
('2023-01-21', 'Enrolled', 7, 7, 7, 1, 'C+'),
('2023-01-22', 'Enrolled', 8, 8, 8, 8, 'TBD'),
('2023-01-23', 'Enrolled', 9, 9, 9, 9, 'B-'),
('2023-01-24', 'Enrolled', 10, 10, 1, 10, 'A-'),
('2023-01-25', 'Enrolled', 11, 11, 11, 11, 'B+'),
('2023-01-26', 'Enrolled', 12, 12, 1, 12, 'A'),
('2023-01-27', 'Enrolled', 13, 13, 1, 13, 'TBD'),
('2023-01-28', 'Enrolled', 14, 14, 14, 14, 'C-'),
('2023-01-29', 'Enrolled', 15, 15, 1, 15, 'B+'),
('2023-01-30', 'Enrolled', 16, 16, 16, 16, 'A'),
('2023-01-31', 'Enrolled', 17, 17, 17, 17, 'B'),
('2023-02-01', 'Enrolled', 18, 18, 18, 18, 'TBD'),
('2023-02-02', 'Enrolled', 19, 19, 19, 19, 'B-'),
('2023-02-03', 'Enrolled', 20, 20, 20, 20, 'A');


DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`username`, `role`) VALUES
('bsmith', 'admin'),
('pjones', 'advisor'),
('jdoe', 'student');